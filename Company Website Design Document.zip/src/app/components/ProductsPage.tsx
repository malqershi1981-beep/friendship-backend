import { useState } from "react";
import { ShoppingCart, Search, Filter } from "lucide-react";
import { useApp } from "../context/AppContext";

interface ProductsPageProps {
  category: "stationery" | "computers" | "banking";
}

export function ProductsPage({ category }: ProductsPageProps) {
  const { lang, t, products, addToCart, setCurrentPage } = useApp();
  const isRtl = lang === "ar";
  const [search, setSearch] = useState("");
  const [addedId, setAddedId] = useState<string | null>(null);
  const [qty, setQty] = useState<Record<string, number>>({});

  const catLabel = { stationery: { ar: "القرطاسية", en: "Stationery" }, computers: { ar: "الكمبيوترات ومستلزماتها", en: "Computers & Accessories" }, banking: { ar: "خدمات البنوك", en: "Banking Services" } };
  const catHero = { stationery: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200&h=300&fit=crop&auto=format", computers: "https://images.unsplash.com/photo-1498049794561-7780e7231661?w=1200&h=300&fit=crop&auto=format", banking: "https://images.unsplash.com/photo-1601597111158-2fceff292cdc?w=1200&h=300&fit=crop&auto=format" };

  const filtered = products.filter(p => p.category === category && p.available && (
    search === "" || p.nameAr.includes(search) || p.nameEn.toLowerCase().includes(search.toLowerCase())
  ));

  const handleAdd = (p: typeof products[0]) => {
    addToCart(p, qty[p.id] || 1);
    setAddedId(p.id);
    setTimeout(() => setAddedId(null), 1500);
  };

  return (
    <div dir={isRtl ? "rtl" : "ltr"} style={{ fontFamily: isRtl ? "Cairo, sans-serif" : "Inter, sans-serif" }}>
      {/* Hero */}
      <div className="relative overflow-hidden" style={{ height: "200px" }}>
        <img src={catHero[category]} alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-primary/70 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 style={{ fontSize: "36px", fontWeight: 800 }}>
              {isRtl ? catLabel[category].ar : catLabel[category].en}
            </h1>
            <p className="opacity-80 mt-2">{filtered.length} {t("منتج متوفر", "products available")}</p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Search */}
        <div className="flex gap-4 mb-8">
          <div className="relative flex-1 max-w-md">
            <Search size={18} className="absolute top-1/2 -translate-y-1/2 text-muted-foreground" style={{ [isRtl ? "right" : "left"]: "12px" }} />
            <input
              placeholder={t("ابحث عن منتج...", "Search products...")}
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full py-2.5 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-primary/30"
              style={{ [isRtl ? "paddingRight" : "paddingLeft"]: "40px", paddingLeft: isRtl ? "16px" : "40px", paddingRight: isRtl ? "40px" : "16px" }}
            />
          </div>
          <button onClick={() => setCurrentPage("cart")} className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-accent text-white hover:opacity-90 transition-opacity" style={{ fontWeight: 600 }}>
            <ShoppingCart size={18} />
            {t("عرض السلة", "View Cart")}
          </button>
        </div>

        {/* Products grid */}
        {filtered.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            <Filter size={48} className="mx-auto mb-4 opacity-40" />
            <p style={{ fontSize: "18px" }}>{t("لا توجد منتجات", "No products found")}</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filtered.map(p => (
              <div key={p.id} className="bg-white rounded-2xl shadow-sm border border-border overflow-hidden hover:shadow-lg transition-all hover:-translate-y-1 flex flex-col">
                <div className="overflow-hidden" style={{ height: "200px" }}>
                  <img src={p.image} alt={isRtl ? p.nameAr : p.nameEn} className="w-full h-full object-cover hover:scale-105 transition-transform duration-300" />
                </div>
                <div className="p-5 flex flex-col flex-1">
                  <h3 style={{ fontWeight: 700, color: "var(--foreground)", marginBottom: "6px" }}>
                    {isRtl ? p.nameAr : p.nameEn}
                  </h3>
                  <p className="text-muted-foreground flex-1" style={{ fontSize: "13px", marginBottom: "12px" }}>
                    {isRtl ? p.descAr : p.descEn}
                  </p>
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-muted-foreground" style={{ fontSize: "13px" }}>{t("الكمية:", "Qty:")}</span>
                    <input
                      type="number"
                      min={1}
                      max={p.stock}
                      value={qty[p.id] || 1}
                      onChange={e => setQty(q => ({ ...q, [p.id]: Math.max(1, parseInt(e.target.value) || 1) }))}
                      className="w-20 px-2 py-1 rounded-lg border border-border text-center focus:outline-none focus:ring-2 focus:ring-primary/30"
                      style={{ fontSize: "14px" }}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-accent" style={{ fontWeight: 700, fontSize: "20px" }}>
                      {p.price.toFixed(2)} <span style={{ fontSize: "12px" }}>{t("ج.س", "SDG")}</span>
                    </span>
                    <button
                      onClick={() => handleAdd(p)}
                      className={`flex items-center gap-1.5 px-4 py-2 rounded-xl transition-all ${addedId === p.id ? "bg-green-500 text-white" : "bg-primary text-primary-foreground hover:opacity-90"}`}
                      style={{ fontWeight: 600, fontSize: "14px" }}
                    >
                      <ShoppingCart size={16} />
                      {addedId === p.id ? t("✓ تمت الإضافة", "✓ Added") : t("أضف", "Add")}
                    </button>
                  </div>
                  <div className="mt-2 text-muted-foreground" style={{ fontSize: "12px" }}>
                    {t("المتوفر:", "Stock:")} {p.stock} {t("وحدة", "units")}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
