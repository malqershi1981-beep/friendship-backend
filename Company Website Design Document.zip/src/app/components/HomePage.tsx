import { useState } from "react";
import { Star, ChevronLeft, ChevronRight, Send, Phone, Mail, MapPin, Award, Shield, Truck, Users } from "lucide-react";
import { useApp } from "../context/AppContext";

export function HomePage() {
  const { lang, t, products, setCurrentPage, setSelectedCategory, addToCart, reviews, setReviews } = useApp();
  const isRtl = lang === "ar";
  const [reviewForm, setReviewForm] = useState({ name: "", rating: 5, comment: "", type: "review" as "review" | "complaint" | "suggestion" });
  const [complaintForm, setComplaintForm] = useState({ name: "", message: "" });
  const [formSuccess, setFormSuccess] = useState(false);
  const [complaintSuccess, setComplaintSuccess] = useState(false);

  const featured = products.filter(p => p.available).slice(0, 4);
  const visibleReviews = reviews.filter(r => !r.hidden && r.type === "review");

  const sections = [
    { key: "stationery", ar: "القرطاسية", en: "Stationery", icon: "📝", desc: t("أدوات مكتبية متنوعة وعالية الجودة", "Diverse high-quality office supplies"), color: "bg-blue-50 border-blue-200" },
    { key: "computers", ar: "الكمبيوترات", en: "Computers", icon: "💻", desc: t("أحدث الأجهزة والمستلزمات الإلكترونية", "Latest devices and electronics accessories"), color: "bg-purple-50 border-purple-200" },
    { key: "banking", ar: "خدمات البنوك", en: "Banking Services", icon: "🏦", desc: t("خدمات مالية وبنكية متكاملة", "Comprehensive banking and financial services"), color: "bg-green-50 border-green-200" },
  ];

  const stats = [
    { icon: <Users size={28} />, value: "500+", label: t("عميل راضٍ", "Happy Clients") },
    { icon: <Award size={28} />, value: "10+", label: t("سنوات خبرة", "Years Experience") },
    { icon: <Truck size={28} />, value: "1000+", label: t("طلب مُسلَّم", "Orders Delivered") },
    { icon: <Shield size={28} />, value: "100%", label: t("ضمان الجودة", "Quality Guarantee") },
  ];

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setReviews(prev => [...prev, {
      id: `r${Date.now()}`,
      customerName: reviewForm.name,
      rating: reviewForm.rating,
      comment: reviewForm.comment,
      type: reviewForm.type,
      hidden: false,
      createdAt: new Date()
    }]);
    setFormSuccess(true);
    setReviewForm({ name: "", rating: 5, comment: "", type: "review" });
    setTimeout(() => setFormSuccess(false), 3000);
  };

  const handleComplaintSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setReviews(prev => [...prev, {
      id: `c${Date.now()}`,
      customerName: complaintForm.name,
      rating: 1,
      comment: complaintForm.message,
      type: "complaint",
      hidden: false,
      createdAt: new Date()
    }]);
    setComplaintSuccess(true);
    setComplaintForm({ name: "", message: "" });
    setTimeout(() => setComplaintSuccess(false), 3000);
  };

  return (
    <div dir={isRtl ? "rtl" : "ltr"} style={{ fontFamily: isRtl ? "Cairo, sans-serif" : "Inter, sans-serif" }}>
      {/* Hero */}
      <section className="relative bg-primary overflow-hidden" style={{ minHeight: "500px" }}>
        <div
          className="absolute inset-0 opacity-10"
          style={{ backgroundImage: "url(https://images.unsplash.com/photo-1497366216548-37526070297c?w=1400&h=600&fit=crop&auto=format)", backgroundSize: "cover", backgroundPosition: "center" }}
        />
        <div className="relative max-w-7xl mx-auto px-6 py-24 text-center text-white">
          <div className="inline-block bg-accent/80 text-white px-4 py-1.5 rounded-full mb-6" style={{ fontSize: "13px" }}>
            {t("مرحباً بكم في شركة الصداقة", "Welcome to Al-Sadaqa Company")}
          </div>
          <h1 className="mb-5" style={{ fontSize: "clamp(2rem, 5vw, 3.5rem)", fontWeight: 800, lineHeight: 1.2 }}>
            {t("شركة الصداقة للتجارة", "Al-Sadaqa Trading Company")}
            <br />
            <span className="text-accent">{t("والتوكيلات العامة", "& General Agencies")}</span>
          </h1>
          <p className="max-w-2xl mx-auto mb-8 opacity-85" style={{ fontSize: "18px", lineHeight: 1.7 }}>
            {t(
              "نقدم لكم أفضل المنتجات المكتبية والإلكترونية والخدمات البنكية بجودة عالية وأسعار تنافسية مع توصيل سريع وموثوق.",
              "We offer the best office supplies, electronics, and banking services with high quality, competitive prices, and fast reliable delivery."
            )}
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <button onClick={() => setCurrentPage("stationery")} className="px-8 py-3.5 rounded-xl bg-accent text-white hover:opacity-90 transition-opacity" style={{ fontWeight: 600 }}>
              {t("تصفح المنتجات", "Browse Products")}
            </button>
            <button onClick={() => setCurrentPage("track")} className="px-8 py-3.5 rounded-xl bg-white/15 border border-white/30 text-white hover:bg-white/25 transition-colors">
              {t("تتبع طلبك", "Track Your Order")}
            </button>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-white border-b border-border">
        <div className="max-w-7xl mx-auto px-6 py-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((s, i) => (
              <div key={i} className="text-center">
                <div className="text-primary mx-auto mb-2 flex justify-center">{s.icon}</div>
                <div className="text-primary" style={{ fontSize: "28px", fontWeight: 800 }}>{s.value}</div>
                <div className="text-muted-foreground" style={{ fontSize: "14px" }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About */}
      <section className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <div className="text-accent mb-2" style={{ fontSize: "13px", fontWeight: 600, textTransform: "uppercase", letterSpacing: "1px" }}>
              {t("من نحن", "About Us")}
            </div>
            <h2 style={{ fontSize: "32px", fontWeight: 700, color: "var(--primary)", marginBottom: "16px" }}>
              {t("نبذة عن الشركة", "Company Overview")}
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-6" style={{ fontSize: "16px" }}>
              {t(
                "شركة الصداقة للتجارة والتوكيلات العامة شركة رائدة في مجال توريد المستلزمات المكتبية والتقنية والخدمات البنكية. نسعى دائماً لتقديم أفضل تجربة تسوق لعملائنا من خلال منتجات متميزة وخدمة عملاء احترافية.",
                "Al-Sadaqa Trading and General Agencies is a leading company in supplying office supplies, technology products, and banking services. We always strive to provide the best shopping experience through premium products and professional customer service."
              )}
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-secondary border border-border">
                <div className="text-primary mb-1" style={{ fontWeight: 700 }}>{t("رؤيتنا", "Our Vision")}</div>
                <p className="text-muted-foreground" style={{ fontSize: "14px" }}>
                  {t("أن نكون الخيار الأول لتوريد الاحتياجات المكتبية والتقنية في السودان", "To be the first choice for office and tech supplies in Sudan")}
                </p>
              </div>
              <div className="p-4 rounded-xl bg-secondary border border-border">
                <div className="text-primary mb-1" style={{ fontWeight: 700 }}>{t("رسالتنا", "Our Mission")}</div>
                <p className="text-muted-foreground" style={{ fontSize: "14px" }}>
                  {t("تقديم منتجات وخدمات عالية الجودة بأسعار مناسبة مع ضمان رضا العميل", "Delivering high-quality products and services at fair prices while ensuring customer satisfaction")}
                </p>
              </div>
            </div>
          </div>
          <div className="rounded-2xl overflow-hidden shadow-lg">
            <img
              src="https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=600&h=400&fit=crop&auto=format"
              alt={t("مكتب شركة الصداقة", "Al-Sadaqa office")}
              className="w-full h-full object-cover"
              style={{ minHeight: "300px" }}
            />
          </div>
        </div>
      </section>

      {/* Sections */}
      <section className="bg-secondary py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div className="text-accent mb-2" style={{ fontSize: "13px", fontWeight: 600, textTransform: "uppercase", letterSpacing: "1px" }}>
              {t("أقسامنا", "Our Sections")}
            </div>
            <h2 style={{ fontSize: "32px", fontWeight: 700, color: "var(--primary)" }}>
              {t("تصفح الأقسام الرئيسية", "Browse Our Main Sections")}
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {sections.map(sec => (
              <button
                key={sec.key}
                onClick={() => { setSelectedCategory(sec.key); setCurrentPage(sec.key); }}
                className={`p-8 rounded-2xl border-2 ${sec.color} text-${isRtl ? "right" : "left"} hover:shadow-lg transition-all hover:-translate-y-1 bg-white`}
              >
                <div style={{ fontSize: "48px" }} className="mb-4">{sec.icon}</div>
                <h3 style={{ fontSize: "22px", fontWeight: 700, color: "var(--primary)", marginBottom: "8px" }}>
                  {isRtl ? sec.ar : sec.en}
                </h3>
                <p className="text-muted-foreground" style={{ fontSize: "14px" }}>{sec.desc}</p>
                <div className="mt-4 text-accent flex items-center gap-1" style={{ fontWeight: 600, fontSize: "14px" }}>
                  {t("تصفح المنتجات", "Browse Products")}
                  {isRtl ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Featured products */}
      <section className="max-w-7xl mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <div className="text-accent mb-2" style={{ fontSize: "13px", fontWeight: 600, textTransform: "uppercase", letterSpacing: "1px" }}>
            {t("المميزة", "Featured")}
          </div>
          <h2 style={{ fontSize: "32px", fontWeight: 700, color: "var(--primary)" }}>
            {t("المنتجات المميزة", "Featured Products")}
          </h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featured.map(p => (
            <div key={p.id} className="bg-white rounded-2xl shadow-sm border border-border overflow-hidden hover:shadow-lg transition-all hover:-translate-y-1">
              <div className="overflow-hidden" style={{ height: "180px" }}>
                <img src={p.image} alt={isRtl ? p.nameAr : p.nameEn} className="w-full h-full object-cover hover:scale-105 transition-transform duration-300" />
              </div>
              <div className="p-4">
                <div className="text-muted-foreground mb-1" style={{ fontSize: "12px" }}>
                  {p.category === "stationery" ? t("قرطاسية", "Stationery") : p.category === "computers" ? t("كمبيوترات", "Computers") : t("بنوك", "Banking")}
                </div>
                <h4 style={{ fontWeight: 600, color: "var(--foreground)", marginBottom: "8px" }}>
                  {isRtl ? p.nameAr : p.nameEn}
                </h4>
                <div className="flex items-center justify-between mt-3">
                  <span className="text-accent" style={{ fontWeight: 700, fontSize: "18px" }}>
                    {p.price.toFixed(2)} {t("ج.س", "SDG")}
                  </span>
                  <button
                    onClick={() => addToCart(p, 1)}
                    className="px-3 py-1.5 rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-opacity"
                    style={{ fontSize: "13px", fontWeight: 600 }}
                  >
                    {t("أضف للسلة", "Add to Cart")}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Reviews */}
      <section className="bg-secondary py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div className="text-accent mb-2" style={{ fontSize: "13px", fontWeight: 600, textTransform: "uppercase", letterSpacing: "1px" }}>
              {t("آراء العملاء", "Customer Reviews")}
            </div>
            <h2 style={{ fontSize: "32px", fontWeight: 700, color: "var(--primary)" }}>
              {t("ماذا يقول عملاؤنا", "What Our Clients Say")}
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            {visibleReviews.slice(0, 3).map(r => (
              <div key={r.id} className="bg-white p-6 rounded-2xl shadow-sm border border-border">
                <div className="flex gap-1 mb-3">
                  {[1,2,3,4,5].map(s => (
                    <Star key={s} size={16} className={s <= r.rating ? "fill-accent text-accent" : "text-gray-200 fill-gray-200"} />
                  ))}
                </div>
                <p className="text-muted-foreground leading-relaxed mb-4" style={{ fontSize: "14px" }}>{r.comment}</p>
                <div style={{ fontWeight: 600, color: "var(--primary)", fontSize: "14px" }}>— {r.customerName}</div>
              </div>
            ))}
          </div>

          {/* Review form */}
          <div className="max-w-2xl mx-auto bg-white p-8 rounded-2xl shadow-sm border border-border">
            <h3 style={{ fontSize: "20px", fontWeight: 700, color: "var(--primary)", marginBottom: "20px" }}>
              {t("أضف تقييمك", "Add Your Review")}
            </h3>
            {formSuccess ? (
              <div className="text-center py-6 text-green-600" style={{ fontWeight: 600 }}>
                ✓ {t("شكراً لتقييمك!", "Thank you for your review!")}
              </div>
            ) : (
              <form onSubmit={handleReviewSubmit} className="space-y-4">
                <input
                  required
                  placeholder={t("اسمك", "Your Name")}
                  value={reviewForm.name}
                  onChange={e => setReviewForm(f => ({ ...f, name: e.target.value }))}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30"
                />
                <div className="flex gap-2 items-center">
                  <span className="text-muted-foreground" style={{ fontSize: "14px" }}>{t("التقييم:", "Rating:")}</span>
                  {[1,2,3,4,5].map(s => (
                    <button type="button" key={s} onClick={() => setReviewForm(f => ({ ...f, rating: s }))}>
                      <Star size={24} className={s <= reviewForm.rating ? "fill-accent text-accent" : "text-gray-300 fill-gray-300"} />
                    </button>
                  ))}
                </div>
                <select
                  value={reviewForm.type}
                  onChange={e => setReviewForm(f => ({ ...f, type: e.target.value as any }))}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30"
                >
                  <option value="review">{t("تقييم", "Review")}</option>
                  <option value="complaint">{t("شكوى", "Complaint")}</option>
                  <option value="suggestion">{t("اقتراح", "Suggestion")}</option>
                </select>
                <textarea
                  required
                  rows={3}
                  placeholder={t("اكتب تعليقك هنا...", "Write your comment here...")}
                  value={reviewForm.comment}
                  onChange={e => setReviewForm(f => ({ ...f, comment: e.target.value }))}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30 resize-none"
                />
                <button type="submit" className="flex items-center gap-2 px-6 py-2.5 rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-opacity" style={{ fontWeight: 600 }}>
                  <Send size={16} />
                  {t("إرسال التقييم", "Submit Review")}
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* Complaints */}
      <section className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-2 gap-12">
          {/* Complaint form */}
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-border">
            <h3 style={{ fontSize: "20px", fontWeight: 700, color: "var(--primary)", marginBottom: "6px" }}>
              {t("الشكاوى والاقتراحات", "Complaints & Suggestions")}
            </h3>
            <p className="text-muted-foreground mb-6" style={{ fontSize: "14px" }}>
              {t("رأيك يهمنا لتحسين خدماتنا", "Your feedback helps us improve our services")}
            </p>
            {complaintSuccess ? (
              <div className="text-center py-6 text-green-600" style={{ fontWeight: 600 }}>
                ✓ {t("تم استلام رسالتك، شكراً!", "Your message received, thank you!")}
              </div>
            ) : (
              <form onSubmit={handleComplaintSubmit} className="space-y-4">
                <input
                  required
                  placeholder={t("اسمك", "Your Name")}
                  value={complaintForm.name}
                  onChange={e => setComplaintForm(f => ({ ...f, name: e.target.value }))}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30"
                />
                <textarea
                  required
                  rows={4}
                  placeholder={t("اكتب شكواك أو اقتراحك...", "Write your complaint or suggestion...")}
                  value={complaintForm.message}
                  onChange={e => setComplaintForm(f => ({ ...f, message: e.target.value }))}
                  className="w-full px-4 py-2.5 rounded-lg border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30 resize-none"
                />
                <button type="submit" className="flex items-center gap-2 px-6 py-2.5 rounded-lg bg-accent text-white hover:opacity-90 transition-opacity" style={{ fontWeight: 600 }}>
                  <Send size={16} />
                  {t("إرسال", "Send")}
                </button>
              </form>
            )}
          </div>

          {/* Contact info */}
          <div className="space-y-6">
            <h3 style={{ fontSize: "20px", fontWeight: 700, color: "var(--primary)", marginBottom: "6px" }}>
              {t("معلومات التواصل", "Contact Information")}
            </h3>
            <p className="text-muted-foreground" style={{ fontSize: "14px" }}>
              {t("نحن هنا لخدمتكم في أي وقت", "We are here to serve you at any time")}
            </p>
            {[
              { icon: <Phone size={20} />, label: t("الهاتف", "Phone"), value: "+249 912 345 678" },
              { icon: <Mail size={20} />, label: t("البريد الإلكتروني", "Email"), value: "info@alsadaqa.sd" },
              { icon: <MapPin size={20} />, label: t("العنوان", "Address"), value: t("الخرطوم، السودان", "Khartoum, Sudan") },
            ].map((c, i) => (
              <div key={i} className="flex items-start gap-4 p-4 rounded-xl bg-secondary border border-border">
                <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center text-primary-foreground flex-shrink-0">
                  {c.icon}
                </div>
                <div>
                  <div className="text-muted-foreground" style={{ fontSize: "13px" }}>{c.label}</div>
                  <div style={{ fontWeight: 600, color: "var(--foreground)" }}>{c.value}</div>
                </div>
              </div>
            ))}

            <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
              <div style={{ fontWeight: 600, color: "var(--primary)", marginBottom: "4px" }}>
                {t("ساعات العمل", "Working Hours")}
              </div>
              <div className="text-muted-foreground" style={{ fontSize: "14px" }}>
                {t("السبت – الخميس: 8:00 ص – 5:00 م", "Saturday – Thursday: 8:00 AM – 5:00 PM")}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-8">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <div style={{ fontWeight: 700, fontSize: "18px", marginBottom: "8px" }}>
            {t("شركة الصداقة للتجارة والتوكيلات العامة", "Al-Sadaqa Trading & General Agencies")}
          </div>
          <div className="opacity-60" style={{ fontSize: "14px" }}>
            © 2026 {t("جميع الحقوق محفوظة", "All rights reserved")}
          </div>
        </div>
      </footer>
    </div>
  );
}
