import { useState } from "react";
import { Trash2, ShoppingBag, FileText, CreditCard, Building2, Banknote } from "lucide-react";
import { useApp } from "../context/AppContext";
import type { Order } from "../context/AppContext";
import jsPDF from "jspdf";

export function CartPage() {
  const { lang, t, cart, removeFromCart, updateCartQty, clearCart, cartTotal, banks, setCurrentPage, setOrders, orders } = useApp();
  const isRtl = lang === "ar";

  const [step, setStep] = useState<"cart" | "checkout" | "success">("cart");
  const [orderType, setOrderType] = useState<"quotation" | "purchase">("purchase");
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "bank_transfer">("cash");
  const [selectedBank, setSelectedBank] = useState("");
  const [transferRef, setTransferRef] = useState("");
  const [validity, setValidity] = useState(7);
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);

  const activeBanks = banks.filter(b => b.active);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const order: Order = {
      id: `ORD-${Date.now()}`,
      customerName,
      customerPhone,
      deliveryAddress,
      items: [...cart],
      total: cartTotal,
      paymentMethod,
      bankId: paymentMethod === "bank_transfer" ? selectedBank : undefined,
      transferRef: paymentMethod === "bank_transfer" ? transferRef : undefined,
      status: orderType === "quotation" ? "closed" : "pending",
      createdAt: new Date(),
      isQuotation: orderType === "quotation",
      quotationValidity: orderType === "quotation" ? validity : undefined,
    };
    setOrders(prev => [...prev, order]);
    setCreatedOrder(order);
    clearCart();
    setStep("success");
  };

  const downloadQuotationPDF = () => {
    if (!createdOrder) return;
    const doc = new jsPDF();
    doc.setFont("helvetica");
    doc.setFontSize(18);
    doc.text("Al-Sadaqa Trading Company", 14, 20);
    doc.setFontSize(12);
    doc.text(`Quotation: ${createdOrder.id}`, 14, 32);
    doc.text(`Date: ${createdOrder.createdAt.toLocaleDateString()}`, 14, 40);
    doc.text(`Valid for: ${createdOrder.quotationValidity} days`, 14, 48);
    doc.text(`Customer: ${createdOrder.customerName}`, 14, 60);
    doc.text(`Phone: ${createdOrder.customerPhone}`, 14, 68);
    doc.line(14, 76, 196, 76);
    doc.text("Item", 14, 84);
    doc.text("Qty", 120, 84);
    doc.text("Price", 150, 84);
    doc.text("Total", 175, 84);
    doc.line(14, 88, 196, 88);
    let y = 96;
    createdOrder.items.forEach(item => {
      doc.text(item.product.nameEn.substring(0, 40), 14, y);
      doc.text(String(item.quantity), 120, y);
      doc.text(item.product.price.toFixed(2), 150, y);
      doc.text((item.product.price * item.quantity).toFixed(2), 175, y);
      y += 8;
    });
    doc.line(14, y, 196, y);
    y += 8;
    doc.setFontSize(13);
    doc.text(`Total: ${createdOrder.total.toFixed(2)} SDG`, 14, y);
    doc.save(`quotation-${createdOrder.id}.pdf`);
  };

  if (step === "success" && createdOrder) {
    return (
      <div dir={isRtl ? "rtl" : "ltr"} style={{ fontFamily: isRtl ? "Cairo, sans-serif" : "Inter, sans-serif" }} className="min-h-screen bg-background flex items-center justify-center p-6">
        <div className="bg-white rounded-2xl shadow-lg border border-border p-10 max-w-lg w-full text-center">
          <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6">
            <span style={{ fontSize: "40px" }}>✓</span>
          </div>
          <h2 style={{ fontSize: "26px", fontWeight: 700, color: "var(--primary)", marginBottom: "8px" }}>
            {createdOrder.isQuotation ? t("تم إنشاء عرض السعر", "Quotation Created") : t("تم إرسال طلبك", "Order Submitted")}
          </h2>
          <p className="text-muted-foreground mb-4">
            {t("رقم الطلب:", "Order ID:")} <strong className="text-foreground">{createdOrder.id}</strong>
          </p>
          {createdOrder.isQuotation && (
            <p className="text-muted-foreground mb-6" style={{ fontSize: "14px" }}>
              {t(`صالح لمدة ${createdOrder.quotationValidity} يوم`, `Valid for ${createdOrder.quotationValidity} days`)}
            </p>
          )}
          <div className="flex flex-col gap-3">
            {createdOrder.isQuotation && (
              <button onClick={downloadQuotationPDF} className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground hover:opacity-90 transition-opacity" style={{ fontWeight: 600 }}>
                <FileText size={18} />
                {t("تنزيل PDF", "Download PDF")}
              </button>
            )}
            {!createdOrder.isQuotation && (
              <button onClick={() => { setCurrentPage("track"); }} className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground hover:opacity-90 transition-opacity" style={{ fontWeight: 600 }}>
                {t("تتبع الطلب", "Track Order")}
              </button>
            )}
            <button onClick={() => { setCurrentPage("home"); setStep("cart"); }} className="px-6 py-3 rounded-xl border border-border hover:bg-secondary transition-colors" style={{ fontWeight: 600 }}>
              {t("العودة للرئيسية", "Back to Home")}
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (cart.length === 0 && step === "cart") {
    return (
      <div dir={isRtl ? "rtl" : "ltr"} style={{ fontFamily: isRtl ? "Cairo, sans-serif" : "Inter, sans-serif" }} className="min-h-screen bg-background flex items-center justify-center p-6">
        <div className="text-center">
          <ShoppingBag size={80} className="mx-auto mb-6 text-muted-foreground opacity-40" />
          <h2 style={{ fontSize: "24px", fontWeight: 700, color: "var(--foreground)", marginBottom: "8px" }}>
            {t("سلتك فارغة", "Your cart is empty")}
          </h2>
          <p className="text-muted-foreground mb-8">{t("أضف بعض المنتجات للبدء", "Add some products to get started")}</p>
          <button onClick={() => setCurrentPage("stationery")} className="px-8 py-3 rounded-xl bg-primary text-primary-foreground hover:opacity-90 transition-opacity" style={{ fontWeight: 600 }}>
            {t("تصفح المنتجات", "Browse Products")}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div dir={isRtl ? "rtl" : "ltr"} style={{ fontFamily: isRtl ? "Cairo, sans-serif" : "Inter, sans-serif" }} className="bg-background min-h-screen">
      <div className="max-w-5xl mx-auto px-6 py-10">
        <h1 style={{ fontSize: "30px", fontWeight: 800, color: "var(--primary)", marginBottom: "8px" }}>
          {step === "cart" ? t("سلة المشتريات", "Shopping Cart") : t("إتمام الطلب", "Checkout")}
        </h1>

        {step === "cart" && (
          <>
            {/* Order type */}
            <div className="flex gap-3 mb-6">
              <button
                onClick={() => setOrderType("purchase")}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl border-2 transition-all ${orderType === "purchase" ? "border-primary bg-primary text-primary-foreground" : "border-border bg-white hover:border-primary/50"}`}
                style={{ fontWeight: 600 }}
              >
                <CreditCard size={18} />
                {t("طلب شراء", "Purchase Order")}
              </button>
              <button
                onClick={() => setOrderType("quotation")}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl border-2 transition-all ${orderType === "quotation" ? "border-primary bg-primary text-primary-foreground" : "border-border bg-white hover:border-primary/50"}`}
                style={{ fontWeight: 600 }}
              >
                <FileText size={18} />
                {t("طلب عرض سعر", "Request Quotation")}
              </button>
            </div>

            {/* Cart items */}
            <div className="bg-white rounded-2xl shadow-sm border border-border overflow-hidden mb-6">
              {cart.map((item, idx) => (
                <div key={item.product.id} className={`flex items-center gap-4 p-4 ${idx < cart.length - 1 ? "border-b border-border" : ""}`}>
                  <img src={item.product.image} alt="" className="w-16 h-16 rounded-xl object-cover flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div style={{ fontWeight: 600, color: "var(--foreground)" }}>{isRtl ? item.product.nameAr : item.product.nameEn}</div>
                    <div className="text-accent" style={{ fontWeight: 700 }}>{item.product.price.toFixed(2)} {t("ج.س", "SDG")}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => updateCartQty(item.product.id, item.quantity - 1)} className="w-8 h-8 rounded-lg border border-border flex items-center justify-center hover:bg-secondary transition-colors">−</button>
                    <span className="w-10 text-center" style={{ fontWeight: 600 }}>{item.quantity}</span>
                    <button onClick={() => updateCartQty(item.product.id, item.quantity + 1)} className="w-8 h-8 rounded-lg border border-border flex items-center justify-center hover:bg-secondary transition-colors">+</button>
                  </div>
                  <div style={{ fontWeight: 700, color: "var(--primary)", minWidth: "80px", textAlign: isRtl ? "left" : "right" }}>
                    {(item.product.price * item.quantity).toFixed(2)} {t("ج.س", "SDG")}
                  </div>
                  <button onClick={() => removeFromCart(item.product.id)} className="p-2 rounded-lg hover:bg-red-50 text-destructive transition-colors">
                    <Trash2 size={18} />
                  </button>
                </div>
              ))}
            </div>

            {/* Total & actions */}
            <div className="flex items-center justify-between bg-white rounded-2xl shadow-sm border border-border p-6">
              <div>
                <div className="text-muted-foreground" style={{ fontSize: "14px" }}>{t("الإجمالي", "Total")}</div>
                <div className="text-primary" style={{ fontSize: "28px", fontWeight: 800 }}>
                  {cartTotal.toFixed(2)} {t("ج.س", "SDG")}
                </div>
              </div>
              <button onClick={() => setStep("checkout")} className="px-8 py-3.5 rounded-xl bg-primary text-primary-foreground hover:opacity-90 transition-opacity" style={{ fontWeight: 700, fontSize: "16px" }}>
                {orderType === "quotation" ? t("إنشاء عرض السعر", "Create Quotation") : t("متابعة الدفع", "Proceed to Checkout")}
              </button>
            </div>
          </>
        )}

        {step === "checkout" && (
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Customer info */}
            <div className="bg-white rounded-2xl shadow-sm border border-border p-6">
              <h3 style={{ fontSize: "18px", fontWeight: 700, color: "var(--primary)", marginBottom: "16px" }}>
                {t("بيانات العميل", "Customer Details")}
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block mb-1.5" style={{ fontSize: "14px", fontWeight: 600 }}>{t("الاسم *", "Name *")}</label>
                  <input required value={customerName} onChange={e => setCustomerName(e.target.value)} className="w-full px-4 py-2.5 rounded-xl border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30" />
                </div>
                <div>
                  <label className="block mb-1.5" style={{ fontSize: "14px", fontWeight: 600 }}>{t("رقم الهاتف *", "Phone *")}</label>
                  <input required value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} className="w-full px-4 py-2.5 rounded-xl border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30" />
                </div>
                {orderType !== "quotation" && (
                  <div className="md:col-span-2">
                    <label className="block mb-1.5" style={{ fontSize: "14px", fontWeight: 600 }}>{t("عنوان التوصيل *", "Delivery Address *")}</label>
                    <input required value={deliveryAddress} onChange={e => setDeliveryAddress(e.target.value)} className="w-full px-4 py-2.5 rounded-xl border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30" />
                  </div>
                )}
                {orderType === "quotation" && (
                  <div>
                    <label className="block mb-1.5" style={{ fontSize: "14px", fontWeight: 600 }}>{t("فترة الصلاحية (أيام)", "Validity Period (days)")}</label>
                    <input type="number" min={1} value={validity} onChange={e => setValidity(parseInt(e.target.value) || 7)} className="w-full px-4 py-2.5 rounded-xl border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30" />
                  </div>
                )}
              </div>
            </div>

            {/* Payment */}
            {orderType !== "quotation" && (
              <div className="bg-white rounded-2xl shadow-sm border border-border p-6">
                <h3 style={{ fontSize: "18px", fontWeight: 700, color: "var(--primary)", marginBottom: "16px" }}>
                  {t("طريقة الدفع", "Payment Method")}
                </h3>
                <div className="flex gap-3 mb-5">
                  <button type="button" onClick={() => setPaymentMethod("cash")} className={`flex items-center gap-2 px-5 py-3 rounded-xl border-2 transition-all ${paymentMethod === "cash" ? "border-primary bg-primary text-primary-foreground" : "border-border bg-white hover:border-primary/50"}`} style={{ fontWeight: 600 }}>
                    <Banknote size={20} />
                    {t("نقداً عند التسليم", "Cash on Delivery")}
                  </button>
                  <button type="button" onClick={() => setPaymentMethod("bank_transfer")} className={`flex items-center gap-2 px-5 py-3 rounded-xl border-2 transition-all ${paymentMethod === "bank_transfer" ? "border-primary bg-primary text-primary-foreground" : "border-border bg-white hover:border-primary/50"}`} style={{ fontWeight: 600 }}>
                    <Building2 size={20} />
                    {t("تحويل بنكي", "Bank Transfer")}
                  </button>
                </div>

                {paymentMethod === "bank_transfer" && (
                  <div className="space-y-4">
                    <div>
                      <label className="block mb-1.5" style={{ fontSize: "14px", fontWeight: 600 }}>{t("اختر البنك *", "Select Bank *")}</label>
                      <select required value={selectedBank} onChange={e => setSelectedBank(e.target.value)} className="w-full px-4 py-2.5 rounded-xl border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30">
                        <option value="">{t("-- اختر البنك --", "-- Select Bank --")}</option>
                        {activeBanks.map(b => (
                          <option key={b.id} value={b.id}>{isRtl ? b.nameAr : b.nameEn} — {b.accountNumber}</option>
                        ))}
                      </select>
                    </div>
                    {selectedBank && (
                      <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
                        <div style={{ fontWeight: 600, color: "var(--primary)", marginBottom: "4px" }}>{t("رقم الحساب:", "Account Number:")}</div>
                        <div style={{ fontFamily: "monospace", fontSize: "18px", letterSpacing: "2px" }}>
                          {activeBanks.find(b => b.id === selectedBank)?.accountNumber}
                        </div>
                      </div>
                    )}
                    <div>
                      <label className="block mb-1.5" style={{ fontSize: "14px", fontWeight: 600 }}>{t("الرقم المرجعي للتحويل *", "Transfer Reference Number *")}</label>
                      <input required value={transferRef} onChange={e => setTransferRef(e.target.value)} className="w-full px-4 py-2.5 rounded-xl border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30" placeholder={t("أدخل رقم العملية", "Enter transaction number")} />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Order summary */}
            <div className="bg-white rounded-2xl shadow-sm border border-border p-6">
              <h3 style={{ fontSize: "18px", fontWeight: 700, color: "var(--primary)", marginBottom: "16px" }}>
                {t("ملخص الطلب", "Order Summary")}
              </h3>
              {cart.map(item => (
                <div key={item.product.id} className="flex justify-between py-2 border-b border-border last:border-0">
                  <span>{isRtl ? item.product.nameAr : item.product.nameEn} × {item.quantity}</span>
                  <span style={{ fontWeight: 600 }}>{(item.product.price * item.quantity).toFixed(2)} {t("ج.س", "SDG")}</span>
                </div>
              ))}
              <div className="flex justify-between pt-3 mt-1">
                <span style={{ fontWeight: 700, fontSize: "18px" }}>{t("الإجمالي", "Total")}</span>
                <span className="text-accent" style={{ fontWeight: 800, fontSize: "22px" }}>{cartTotal.toFixed(2)} {t("ج.س", "SDG")}</span>
              </div>
            </div>

            <div className="flex gap-3">
              <button type="button" onClick={() => setStep("cart")} className="flex-1 py-3.5 rounded-xl border border-border bg-white hover:bg-secondary transition-colors" style={{ fontWeight: 600 }}>
                {t("رجوع", "Back")}
              </button>
              <button type="submit" className="flex-1 py-3.5 rounded-xl bg-primary text-primary-foreground hover:opacity-90 transition-opacity" style={{ fontWeight: 700, fontSize: "16px" }}>
                {orderType === "quotation" ? t("إنشاء عرض السعر", "Create Quotation") : t("تأكيد الطلب", "Confirm Order")}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
