import { useState } from "react";
import {
  Package, Building2, Truck, Users, BarChart2, Star, Plus, Edit2, Trash2,
  CheckCircle, XCircle, Eye, EyeOff, TrendingUp, DollarSign, MessageSquare
} from "lucide-react";
import { useApp } from "../context/AppContext";
import type { Product, Bank, DeliveryEmployee, StaffUser } from "../context/AppContext";

type AdminTab = "products" | "banks" | "employees" | "staff" | "revenue" | "reviews";

export function AdminPanel() {
  const { lang, t, products, setProducts, banks, setBanks, employees, setEmployees, staff, setStaff, orders, reviews, setReviews } = useApp();
  const isRtl = lang === "ar";
  const [tab, setTab] = useState<AdminTab>("products");

  const tabs: { key: AdminTab; ar: string; en: string; icon: React.ReactNode }[] = [
    { key: "products", ar: "الأصناف", en: "Products", icon: <Package size={18} /> },
    { key: "banks", ar: "البنوك", en: "Banks", icon: <Building2 size={18} /> },
    { key: "employees", ar: "موظفو التوصيل", en: "Delivery Staff", icon: <Truck size={18} /> },
    { key: "staff", ar: "المستخدمون", en: "Staff Users", icon: <Users size={18} /> },
    { key: "revenue", ar: "الإيرادات", en: "Revenue", icon: <BarChart2 size={18} /> },
    { key: "reviews", ar: "التقييمات", en: "Reviews", icon: <Star size={18} /> },
  ];

  return (
    <div dir={isRtl ? "rtl" : "ltr"} style={{ fontFamily: isRtl ? "Cairo, sans-serif" : "Inter, sans-serif" }} className="flex h-full">
      {/* Sidebar tabs */}
      <div className="w-56 flex-shrink-0 bg-white border-e border-border flex flex-col py-4 gap-1 px-3">
        {tabs.map(tb => (
          <button
            key={tb.key}
            onClick={() => setTab(tb.key)}
            className={`flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all text-sm ${tab === tb.key ? "bg-primary text-primary-foreground" : "hover:bg-secondary text-foreground"}`}
            style={{ fontWeight: 600 }}
          >
            {tb.icon}
            {isRtl ? tb.ar : tb.en}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6 bg-background">
        {tab === "products" && <ProductsAdmin products={products} setProducts={setProducts} lang={lang} t={t} isRtl={isRtl} />}
        {tab === "banks" && <BanksAdmin banks={banks} setBanks={setBanks} lang={lang} t={t} isRtl={isRtl} />}
        {tab === "employees" && <EmployeesAdmin employees={employees} setEmployees={setEmployees} lang={lang} t={t} isRtl={isRtl} />}
        {tab === "staff" && <StaffAdmin staff={staff} setStaff={setStaff} lang={lang} t={t} isRtl={isRtl} />}
        {tab === "revenue" && <RevenueAdmin orders={orders} banks={banks} lang={lang} t={t} isRtl={isRtl} />}
        {tab === "reviews" && <ReviewsAdmin reviews={reviews} setReviews={setReviews} lang={lang} t={t} isRtl={isRtl} />}
      </div>
    </div>
  );
}

// ── Products ────────────────────────────────────────────────────────
function ProductsAdmin({ products, setProducts, lang, t, isRtl }: any) {
  const blank: Omit<Product, "id"> = { nameAr: "", nameEn: "", descAr: "", descEn: "", price: 0, category: "stationery", image: "", stock: 0, available: true };
  const [form, setForm] = useState<Omit<Product, "id">>(blank);
  const [editId, setEditId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);

  const save = () => {
    if (editId) {
      setProducts((prev: Product[]) => prev.map((p: Product) => p.id === editId ? { ...form, id: editId } : p));
      setEditId(null);
    } else {
      setProducts((prev: Product[]) => [...prev, { ...form, id: `p${Date.now()}` }]);
    }
    setForm(blank);
    setShowForm(false);
  };

  const del = (id: string) => setProducts((prev: Product[]) => prev.filter((p: Product) => p.id !== id));

  const edit = (p: Product) => { setForm({ nameAr: p.nameAr, nameEn: p.nameEn, descAr: p.descAr, descEn: p.descEn, price: p.price, category: p.category, image: p.image, stock: p.stock, available: p.available }); setEditId(p.id); setShowForm(true); };

  const catOptions = [{ v: "stationery", ar: "قرطاسية", en: "Stationery" }, { v: "computers", ar: "كمبيوترات", en: "Computers" }, { v: "banking", ar: "خدمات البنوك", en: "Banking" }];

  return (
    <div className="max-w-4xl">
      <div className="flex items-center justify-between mb-6">
        <h2 style={{ fontSize: "22px", fontWeight: 800, color: "var(--primary)" }}>{t("إدارة الأصناف", "Manage Products")}</h2>
        <button onClick={() => { setShowForm(true); setEditId(null); setForm(blank); }} className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground hover:opacity-90 transition-opacity" style={{ fontWeight: 600 }}>
          <Plus size={18} /> {t("إضافة صنف", "Add Product")}
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl border border-border p-6 mb-6">
          <h3 style={{ fontWeight: 700, color: "var(--primary)", marginBottom: "16px" }}>{editId ? t("تعديل الصنف", "Edit Product") : t("إضافة صنف جديد", "Add New Product")}</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <Input label={t("الاسم بالعربية", "Arabic Name")} value={form.nameAr} onChange={v => setForm(f => ({ ...f, nameAr: v }))} />
            <Input label={t("الاسم بالإنجليزية", "English Name")} value={form.nameEn} onChange={v => setForm(f => ({ ...f, nameEn: v }))} />
            <Input label={t("الوصف بالعربية", "Arabic Description")} value={form.descAr} onChange={v => setForm(f => ({ ...f, descAr: v }))} />
            <Input label={t("الوصف بالإنجليزية", "English Description")} value={form.descEn} onChange={v => setForm(f => ({ ...f, descEn: v }))} />
            <Input label={t("السعر", "Price")} type="number" value={String(form.price)} onChange={v => setForm(f => ({ ...f, price: parseFloat(v) || 0 }))} />
            <Input label={t("الكمية المتاحة", "Stock")} type="number" value={String(form.stock)} onChange={v => setForm(f => ({ ...f, stock: parseInt(v) || 0 }))} />
            <Input label={t("رابط الصورة", "Image URL")} value={form.image} onChange={v => setForm(f => ({ ...f, image: v }))} />
            <div>
              <label className="block mb-1.5" style={{ fontSize: "14px", fontWeight: 600 }}>{t("القسم", "Category")}</label>
              <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value as any }))} className="w-full px-4 py-2.5 rounded-xl border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30">
                {catOptions.map(c => <option key={c.v} value={c.v}>{isRtl ? c.ar : c.en}</option>)}
              </select>
            </div>
            <div className="flex items-center gap-3">
              <label style={{ fontWeight: 600, fontSize: "14px" }}>{t("متاح للعرض", "Available")}</label>
              <button type="button" onClick={() => setForm(f => ({ ...f, available: !f.available }))} className={`w-12 h-6 rounded-full transition-colors ${form.available ? "bg-green-500" : "bg-gray-300"} flex items-center`}>
                <span className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${form.available ? (isRtl ? "-translate-x-1" : "translate-x-6") : (isRtl ? "-translate-x-6" : "translate-x-1")}`} />
              </button>
            </div>
          </div>
          <div className="flex gap-3 mt-5">
            <button onClick={save} className="px-6 py-2.5 rounded-xl bg-primary text-primary-foreground hover:opacity-90" style={{ fontWeight: 600 }}>{t("حفظ", "Save")}</button>
            <button onClick={() => { setShowForm(false); setEditId(null); }} className="px-6 py-2.5 rounded-xl border border-border hover:bg-secondary">{t("إلغاء", "Cancel")}</button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {products.map((p: Product) => (
          <div key={p.id} className="bg-white rounded-2xl border border-border p-4 flex items-center gap-4">
            <img src={p.image || "https://images.unsplash.com/photo-1568667256549-094345857637?w=80&h=80&fit=crop"} alt="" className="w-14 h-14 rounded-xl object-cover flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <div style={{ fontWeight: 700 }}>{isRtl ? p.nameAr : p.nameEn}</div>
              <div className="text-muted-foreground" style={{ fontSize: "13px" }}>{catOptions.find(c => c.v === p.category)?.[isRtl ? "ar" : "en"]} — {p.price.toFixed(2)} {t("ج.س", "SDG")} — {t("المخزون:", "Stock:")} {p.stock}</div>
            </div>
            <span className={`text-xs px-2 py-1 rounded-full ${p.available ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`} style={{ fontWeight: 600 }}>
              {p.available ? t("متاح", "Available") : t("غير متاح", "Unavailable")}
            </span>
            <div className="flex gap-2">
              <button onClick={() => edit(p)} className="p-2 rounded-lg hover:bg-secondary transition-colors text-primary"><Edit2 size={16} /></button>
              <button onClick={() => del(p.id)} className="p-2 rounded-lg hover:bg-red-50 transition-colors text-destructive"><Trash2 size={16} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Banks ────────────────────────────────────────────────────────────
function BanksAdmin({ banks, setBanks, lang, t, isRtl }: any) {
  const [form, setForm] = useState({ nameAr: "", nameEn: "", accountNumber: "" });
  const [editId, setEditId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);

  const save = () => {
    if (editId) {
      setBanks((prev: Bank[]) => prev.map((b: Bank) => b.id === editId ? { ...b, ...form } : b));
      setEditId(null);
    } else {
      setBanks((prev: Bank[]) => [...prev, { ...form, id: `b${Date.now()}`, active: true }]);
    }
    setForm({ nameAr: "", nameEn: "", accountNumber: "" });
    setShowForm(false);
  };

  const toggle = (id: string) => setBanks((prev: Bank[]) => prev.map((b: Bank) => b.id === id ? { ...b, active: !b.active } : b));
  const del = (id: string) => setBanks((prev: Bank[]) => prev.filter((b: Bank) => b.id !== id));
  const edit = (b: Bank) => { setForm({ nameAr: b.nameAr, nameEn: b.nameEn, accountNumber: b.accountNumber }); setEditId(b.id); setShowForm(true); };

  return (
    <div className="max-w-2xl">
      <div className="flex items-center justify-between mb-6">
        <h2 style={{ fontSize: "22px", fontWeight: 800, color: "var(--primary)" }}>{t("إدارة البنوك", "Manage Banks")}</h2>
        <button onClick={() => { setShowForm(true); setEditId(null); setForm({ nameAr: "", nameEn: "", accountNumber: "" }); }} className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground hover:opacity-90" style={{ fontWeight: 600 }}>
          <Plus size={18} /> {t("إضافة بنك", "Add Bank")}
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl border border-border p-6 mb-6">
          <h3 style={{ fontWeight: 700, color: "var(--primary)", marginBottom: "16px" }}>{editId ? t("تعديل بنك", "Edit Bank") : t("إضافة بنك", "Add Bank")}</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <Input label={t("الاسم بالعربية", "Arabic Name")} value={form.nameAr} onChange={v => setForm(f => ({ ...f, nameAr: v }))} />
            <Input label={t("الاسم بالإنجليزية", "English Name")} value={form.nameEn} onChange={v => setForm(f => ({ ...f, nameEn: v }))} />
            <div className="md:col-span-2">
              <Input label={t("رقم الحساب", "Account Number")} value={form.accountNumber} onChange={v => setForm(f => ({ ...f, accountNumber: v }))} />
            </div>
          </div>
          <div className="flex gap-3 mt-5">
            <button onClick={save} className="px-6 py-2.5 rounded-xl bg-primary text-primary-foreground hover:opacity-90" style={{ fontWeight: 600 }}>{t("حفظ", "Save")}</button>
            <button onClick={() => { setShowForm(false); setEditId(null); }} className="px-6 py-2.5 rounded-xl border border-border hover:bg-secondary">{t("إلغاء", "Cancel")}</button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {banks.map((b: Bank) => (
          <div key={b.id} className="bg-white rounded-2xl border border-border p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Building2 size={22} className="text-primary" />
            </div>
            <div className="flex-1">
              <div style={{ fontWeight: 700 }}>{isRtl ? b.nameAr : b.nameEn}</div>
              <div className="text-muted-foreground" style={{ fontSize: "13px", fontFamily: "monospace" }}>{b.accountNumber}</div>
            </div>
            <button onClick={() => toggle(b.id)} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition-colors ${b.active ? "bg-green-100 text-green-700 hover:bg-green-200" : "bg-red-100 text-red-700 hover:bg-red-200"}`} style={{ fontWeight: 600 }}>
              {b.active ? <CheckCircle size={14} /> : <XCircle size={14} />}
              {b.active ? t("مفعّل", "Active") : t("موقوف", "Inactive")}
            </button>
            <div className="flex gap-2">
              <button onClick={() => edit(b)} className="p-2 rounded-lg hover:bg-secondary text-primary"><Edit2 size={16} /></button>
              <button onClick={() => del(b.id)} className="p-2 rounded-lg hover:bg-red-50 text-destructive"><Trash2 size={16} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Employees ────────────────────────────────────────────────────────
function EmployeesAdmin({ employees, setEmployees, lang, t, isRtl }: any) {
  const [form, setForm] = useState({ nameAr: "", nameEn: "", phone: "" });
  const [editId, setEditId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);

  const save = () => {
    if (editId) {
      setEmployees((prev: DeliveryEmployee[]) => prev.map((e: DeliveryEmployee) => e.id === editId ? { ...e, ...form } : e));
      setEditId(null);
    } else {
      setEmployees((prev: DeliveryEmployee[]) => [...prev, { ...form, id: `e${Date.now()}`, active: true }]);
    }
    setForm({ nameAr: "", nameEn: "", phone: "" });
    setShowForm(false);
  };

  const toggle = (id: string) => setEmployees((prev: DeliveryEmployee[]) => prev.map((e: DeliveryEmployee) => e.id === id ? { ...e, active: !e.active } : e));
  const del = (id: string) => setEmployees((prev: DeliveryEmployee[]) => prev.filter((e: DeliveryEmployee) => e.id !== id));
  const edit = (e: DeliveryEmployee) => { setForm({ nameAr: e.nameAr, nameEn: e.nameEn, phone: e.phone }); setEditId(e.id); setShowForm(true); };

  return (
    <div className="max-w-2xl">
      <div className="flex items-center justify-between mb-6">
        <h2 style={{ fontSize: "22px", fontWeight: 800, color: "var(--primary)" }}>{t("موظفو التوصيل", "Delivery Employees")}</h2>
        <button onClick={() => { setShowForm(true); setEditId(null); setForm({ nameAr: "", nameEn: "", phone: "" }); }} className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground hover:opacity-90" style={{ fontWeight: 600 }}>
          <Plus size={18} /> {t("إضافة موظف", "Add Employee")}
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl border border-border p-6 mb-6">
          <h3 style={{ fontWeight: 700, color: "var(--primary)", marginBottom: "16px" }}>{editId ? t("تعديل موظف", "Edit Employee") : t("إضافة موظف", "Add Employee")}</h3>
          <div className="grid md:grid-cols-3 gap-4">
            <Input label={t("الاسم بالعربية", "Arabic Name")} value={form.nameAr} onChange={v => setForm(f => ({ ...f, nameAr: v }))} />
            <Input label={t("الاسم بالإنجليزية", "English Name")} value={form.nameEn} onChange={v => setForm(f => ({ ...f, nameEn: v }))} />
            <Input label={t("رقم الهاتف", "Phone")} value={form.phone} onChange={v => setForm(f => ({ ...f, phone: v }))} />
          </div>
          <div className="flex gap-3 mt-5">
            <button onClick={save} className="px-6 py-2.5 rounded-xl bg-primary text-primary-foreground hover:opacity-90" style={{ fontWeight: 600 }}>{t("حفظ", "Save")}</button>
            <button onClick={() => { setShowForm(false); setEditId(null); }} className="px-6 py-2.5 rounded-xl border border-border hover:bg-secondary">{t("إلغاء", "Cancel")}</button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {employees.map((e: DeliveryEmployee) => (
          <div key={e.id} className="bg-white rounded-2xl border border-border p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Truck size={22} className="text-primary" />
            </div>
            <div className="flex-1">
              <div style={{ fontWeight: 700 }}>{isRtl ? e.nameAr : e.nameEn}</div>
              <div className="text-muted-foreground" style={{ fontSize: "13px" }}>📞 {e.phone}</div>
            </div>
            <button onClick={() => toggle(e.id)} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition-colors ${e.active ? "bg-green-100 text-green-700 hover:bg-green-200" : "bg-red-100 text-red-700 hover:bg-red-200"}`} style={{ fontWeight: 600 }}>
              {e.active ? <CheckCircle size={14} /> : <XCircle size={14} />}
              {e.active ? t("مفعّل", "Active") : t("موقوف", "Inactive")}
            </button>
            <div className="flex gap-2">
              <button onClick={() => edit(e)} className="p-2 rounded-lg hover:bg-secondary text-primary"><Edit2 size={16} /></button>
              <button onClick={() => del(e.id)} className="p-2 rounded-lg hover:bg-red-50 text-destructive"><Trash2 size={16} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Staff Users ──────────────────────────────────────────────────────
function StaffAdmin({ staff, setStaff, lang, t, isRtl }: any) {
  const [form, setForm] = useState({ nameAr: "", nameEn: "", username: "", password: "", role: "customer_service" as StaffUser["role"] });
  const [editId, setEditId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);

  const roles = [
    { v: "admin", ar: "مدير النظام", en: "Admin" },
    { v: "customer_service", ar: "خدمة العملاء", en: "Customer Service" },
    { v: "warehouse", ar: "المخازن", en: "Warehouse" },
    { v: "delivery", ar: "التوصيل", en: "Delivery" },
  ];

  const save = () => {
    if (editId) {
      setStaff((prev: StaffUser[]) => prev.map((s: StaffUser) => s.id === editId ? { ...s, ...form } : s));
      setEditId(null);
    } else {
      setStaff((prev: StaffUser[]) => [...prev, { ...form, id: `s${Date.now()}`, active: true }]);
    }
    setForm({ nameAr: "", nameEn: "", username: "", password: "", role: "customer_service" });
    setShowForm(false);
  };

  const toggle = (id: string) => setStaff((prev: StaffUser[]) => prev.map((s: StaffUser) => s.id === id ? { ...s, active: !s.active } : s));
  const del = (id: string) => setStaff((prev: StaffUser[]) => prev.filter((s: StaffUser) => s.id !== id));
  const edit = (s: StaffUser) => { setForm({ nameAr: s.nameAr, nameEn: s.nameEn, username: s.username, password: s.password, role: s.role }); setEditId(s.id); setShowForm(true); };

  return (
    <div className="max-w-3xl">
      <div className="flex items-center justify-between mb-6">
        <h2 style={{ fontSize: "22px", fontWeight: 800, color: "var(--primary)" }}>{t("إدارة المستخدمين", "Manage Staff Users")}</h2>
        <button onClick={() => { setShowForm(true); setEditId(null); }} className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground hover:opacity-90" style={{ fontWeight: 600 }}>
          <Plus size={18} /> {t("إضافة مستخدم", "Add User")}
        </button>
      </div>

      {showForm && (
        <div className="bg-white rounded-2xl border border-border p-6 mb-6">
          <h3 style={{ fontWeight: 700, color: "var(--primary)", marginBottom: "16px" }}>{editId ? t("تعديل مستخدم", "Edit User") : t("مستخدم جديد", "New User")}</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <Input label={t("الاسم بالعربية", "Arabic Name")} value={form.nameAr} onChange={v => setForm(f => ({ ...f, nameAr: v }))} />
            <Input label={t("الاسم بالإنجليزية", "English Name")} value={form.nameEn} onChange={v => setForm(f => ({ ...f, nameEn: v }))} />
            <Input label={t("اسم المستخدم", "Username")} value={form.username} onChange={v => setForm(f => ({ ...f, username: v }))} />
            <Input label={t("كلمة المرور", "Password")} value={form.password} onChange={v => setForm(f => ({ ...f, password: v }))} />
            <div>
              <label className="block mb-1.5" style={{ fontSize: "14px", fontWeight: 600 }}>{t("الصلاحية", "Role")}</label>
              <select value={form.role || ""} onChange={e => setForm(f => ({ ...f, role: e.target.value as any }))} className="w-full px-4 py-2.5 rounded-xl border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30">
                {roles.map(r => <option key={r.v} value={r.v}>{isRtl ? r.ar : r.en}</option>)}
              </select>
            </div>
          </div>
          <div className="flex gap-3 mt-5">
            <button onClick={save} className="px-6 py-2.5 rounded-xl bg-primary text-primary-foreground hover:opacity-90" style={{ fontWeight: 600 }}>{t("حفظ", "Save")}</button>
            <button onClick={() => { setShowForm(false); setEditId(null); }} className="px-6 py-2.5 rounded-xl border border-border hover:bg-secondary">{t("إلغاء", "Cancel")}</button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {staff.map((s: StaffUser) => (
          <div key={s.id} className="bg-white rounded-2xl border border-border p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Users size={20} className="text-primary" />
            </div>
            <div className="flex-1">
              <div style={{ fontWeight: 700 }}>{isRtl ? s.nameAr : s.nameEn}</div>
              <div className="text-muted-foreground" style={{ fontSize: "13px" }}>
                @{s.username} — {roles.find(r => r.v === s.role)?.[isRtl ? "ar" : "en"]}
              </div>
            </div>
            <button onClick={() => toggle(s.id)} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition-colors ${s.active ? "bg-green-100 text-green-700 hover:bg-green-200" : "bg-red-100 text-red-700 hover:bg-red-200"}`} style={{ fontWeight: 600 }}>
              {s.active ? <CheckCircle size={14} /> : <XCircle size={14} />}
              {s.active ? t("مفعّل", "Active") : t("موقوف", "Inactive")}
            </button>
            <div className="flex gap-2">
              <button onClick={() => edit(s)} className="p-2 rounded-lg hover:bg-secondary text-primary"><Edit2 size={16} /></button>
              <button onClick={() => del(s.id)} className="p-2 rounded-lg hover:bg-red-50 text-destructive"><Trash2 size={16} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Revenue ──────────────────────────────────────────────────────────
function RevenueAdmin({ orders, banks, lang, t, isRtl }: any) {
  const [filterType, setFilterType] = useState<"all" | "cash" | "bank_transfer">("all");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  const closed = orders.filter((o: any) => (o.status === "delivered" || o.status === "closed") && !o.isQuotation);

  const filtered = closed.filter((o: any) => {
    const matchType = filterType === "all" || o.paymentMethod === filterType;
    const d = new Date(o.createdAt);
    const matchFrom = !fromDate || d >= new Date(fromDate);
    const matchTo = !toDate || d <= new Date(toDate + "T23:59:59");
    return matchType && matchFrom && matchTo;
  });

  const totalCash = filtered.filter((o: any) => o.paymentMethod === "cash").reduce((s: number, o: any) => s + o.total, 0);
  const totalBank = filtered.filter((o: any) => o.paymentMethod === "bank_transfer").reduce((s: number, o: any) => s + o.total, 0);
  const total = totalCash + totalBank;

  const byBank = banks.map((b: any) => ({
    ...b,
    revenue: filtered.filter((o: any) => o.bankId === b.id).reduce((s: number, o: any) => s + o.total, 0)
  }));

  return (
    <div className="max-w-3xl">
      <h2 style={{ fontSize: "22px", fontWeight: 800, color: "var(--primary)", marginBottom: "24px" }}>{t("تقارير الإيرادات", "Revenue Reports")}</h2>

      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {[
          { label: t("إجمالي الإيرادات", "Total Revenue"), value: total, icon: <TrendingUp size={22} />, color: "bg-primary" },
          { label: t("الإيرادات النقدية", "Cash Revenue"), value: totalCash, icon: <DollarSign size={22} />, color: "bg-green-600" },
          { label: t("التحويل البنكي", "Bank Transfer"), value: totalBank, icon: <Building2 size={22} />, color: "bg-blue-600" },
        ].map((c, i) => (
          <div key={i} className={`${c.color} rounded-2xl p-5 text-white`}>
            <div className="opacity-80 mb-1">{c.icon}</div>
            <div style={{ fontWeight: 800, fontSize: "24px" }}>{c.value.toFixed(2)}</div>
            <div className="opacity-80" style={{ fontSize: "13px" }}>{c.label} {t("ج.س", "SDG")}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl border border-border p-5 mb-6">
        <h3 style={{ fontWeight: 700, color: "var(--primary)", marginBottom: "14px" }}>{t("تصفية التقارير", "Filter Reports")}</h3>
        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <label className="block mb-1.5" style={{ fontSize: "13px", fontWeight: 600 }}>{t("نوع الدفع", "Payment Type")}</label>
            <select value={filterType} onChange={e => setFilterType(e.target.value as any)} className="w-full px-4 py-2.5 rounded-xl border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30">
              <option value="all">{t("الكل", "All")}</option>
              <option value="cash">{t("نقداً", "Cash")}</option>
              <option value="bank_transfer">{t("تحويل بنكي", "Bank Transfer")}</option>
            </select>
          </div>
          <div>
            <label className="block mb-1.5" style={{ fontSize: "13px", fontWeight: 600 }}>{t("من تاريخ", "From Date")}</label>
            <input type="date" value={fromDate} onChange={e => setFromDate(e.target.value)} className="w-full px-4 py-2.5 rounded-xl border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30" />
          </div>
          <div>
            <label className="block mb-1.5" style={{ fontSize: "13px", fontWeight: 600 }}>{t("إلى تاريخ", "To Date")}</label>
            <input type="date" value={toDate} onChange={e => setToDate(e.target.value)} className="w-full px-4 py-2.5 rounded-xl border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30" />
          </div>
        </div>
      </div>

      {/* Revenue by bank */}
      {byBank.some((b: any) => b.revenue > 0) && (
        <div className="bg-white rounded-2xl border border-border p-5 mb-6">
          <h3 style={{ fontWeight: 700, color: "var(--primary)", marginBottom: "14px" }}>{t("الإيرادات حسب البنك", "Revenue by Bank")}</h3>
          {byBank.filter((b: any) => b.revenue > 0).map((b: any) => (
            <div key={b.id} className="flex justify-between py-2 border-b border-border last:border-0">
              <span>{isRtl ? b.nameAr : b.nameEn}</span>
              <span style={{ fontWeight: 700, color: "var(--accent)" }}>{b.revenue.toFixed(2)} {t("ج.س", "SDG")}</span>
            </div>
          ))}
        </div>
      )}

      {/* Orders table */}
      <div className="bg-white rounded-2xl border border-border overflow-hidden">
        <div className="p-4 border-b border-border" style={{ fontWeight: 700, color: "var(--primary)" }}>
          {t("الطلبات المكتملة", "Completed Orders")} ({filtered.length})
        </div>
        {filtered.length === 0 ? (
          <div className="p-8 text-center text-muted-foreground">{t("لا توجد طلبات في هذه الفترة", "No orders in this period")}</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full" style={{ fontSize: "14px" }}>
              <thead className="bg-secondary">
                <tr>
                  {[t("رقم الطلب", "Order ID"), t("العميل", "Customer"), t("الدفع", "Payment"), t("الإجمالي", "Total"), t("التاريخ", "Date")].map((h, i) => (
                    <th key={i} className="px-4 py-3 text-muted-foreground" style={{ fontWeight: 600, textAlign: isRtl ? "right" : "left" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((o: any) => (
                  <tr key={o.id} className="border-t border-border hover:bg-secondary/50">
                    <td className="px-4 py-3" style={{ fontWeight: 600 }}>{o.id}</td>
                    <td className="px-4 py-3">{o.customerName}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-1 rounded-full ${o.paymentMethod === "cash" ? "bg-green-100 text-green-700" : "bg-blue-100 text-blue-700"}`} style={{ fontWeight: 600 }}>
                        {o.paymentMethod === "cash" ? t("نقداً", "Cash") : t("بنكي", "Bank")}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-accent" style={{ fontWeight: 700 }}>{o.total.toFixed(2)} {t("ج.س", "SDG")}</td>
                    <td className="px-4 py-3 text-muted-foreground">{new Date(o.createdAt).toLocaleDateString(isRtl ? "ar" : "en")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Reviews ──────────────────────────────────────────────────────────
function ReviewsAdmin({ reviews, setReviews, lang, t, isRtl }: any) {
  const [filter, setFilter] = useState<"all" | "review" | "complaint" | "suggestion">("all");
  const [replyId, setReplyId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState("");

  const filtered = reviews.filter((r: any) => filter === "all" || r.type === filter);

  const toggle = (id: string) => setReviews((prev: any[]) => prev.map(r => r.id === id ? { ...r, hidden: !r.hidden } : r));
  const submitReply = (id: string) => {
    setReviews((prev: any[]) => prev.map(r => r.id === id ? { ...r, reply: replyText } : r));
    setReplyId(null); setReplyText("");
  };

  const typeLabel = { review: { ar: "تقييم", en: "Review" }, complaint: { ar: "شكوى", en: "Complaint" }, suggestion: { ar: "اقتراح", en: "Suggestion" } };
  const typeColor = { review: "bg-blue-100 text-blue-700", complaint: "bg-red-100 text-red-700", suggestion: "bg-purple-100 text-purple-700" };

  return (
    <div className="max-w-3xl">
      <h2 style={{ fontSize: "22px", fontWeight: 800, color: "var(--primary)", marginBottom: "20px" }}>{t("التقييمات والشكاوى", "Reviews & Complaints")}</h2>

      {/* Filter tabs */}
      <div className="flex gap-2 mb-6 bg-white rounded-xl p-1.5 border border-border w-fit">
        {([["all", t("الكل", "All")], ["review", t("تقييمات", "Reviews")], ["complaint", t("شكاوى", "Complaints")], ["suggestion", t("اقتراحات", "Suggestions")]] as [string, string][]).map(([k, label]) => (
          <button key={k} onClick={() => setFilter(k as any)} className={`px-4 py-2 rounded-lg text-sm transition-colors ${filter === k ? "bg-primary text-primary-foreground" : "hover:bg-secondary"}`} style={{ fontWeight: 600 }}>{label}</button>
        ))}
      </div>

      <div className="space-y-4">
        {filtered.map((r: any) => (
          <div key={r.id} className={`bg-white rounded-2xl border border-border overflow-hidden ${r.hidden ? "opacity-50" : ""}`}>
            <div className="p-5">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div style={{ fontWeight: 700 }}>{r.customerName}</div>
                  <div className="text-muted-foreground" style={{ fontSize: "13px" }}>{new Date(r.createdAt).toLocaleDateString(isRtl ? "ar" : "en")}</div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs px-2 py-1 rounded-full ${typeColor[r.type as keyof typeof typeColor]}`} style={{ fontWeight: 600 }}>
                    {isRtl ? typeLabel[r.type as keyof typeof typeLabel].ar : typeLabel[r.type as keyof typeof typeLabel].en}
                  </span>
                  {r.type === "review" && (
                    <div className="flex gap-0.5">
                      {[1,2,3,4,5].map(s => <Star key={s} size={14} className={s <= r.rating ? "fill-accent text-accent" : "fill-gray-200 text-gray-200"} />)}
                    </div>
                  )}
                </div>
              </div>
              <p className="text-foreground mb-4">{r.comment}</p>
              {r.reply && (
                <div className="p-3 rounded-xl bg-secondary border border-border text-sm">
                  <div className="text-muted-foreground mb-1" style={{ fontWeight: 600 }}>{t("رد الإدارة:", "Admin Reply:")}</div>
                  <div>{r.reply}</div>
                </div>
              )}
              {replyId === r.id && (
                <div className="mt-3 space-y-2">
                  <textarea
                    rows={2}
                    value={replyText}
                    onChange={e => setReplyText(e.target.value)}
                    placeholder={t("اكتب ردك...", "Write your reply...")}
                    className="w-full px-4 py-2.5 rounded-xl border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30 resize-none text-sm"
                  />
                  <div className="flex gap-2">
                    <button onClick={() => submitReply(r.id)} className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm hover:opacity-90" style={{ fontWeight: 600 }}>{t("إرسال الرد", "Send Reply")}</button>
                    <button onClick={() => { setReplyId(null); setReplyText(""); }} className="px-4 py-2 rounded-lg border border-border text-sm hover:bg-secondary">{t("إلغاء", "Cancel")}</button>
                  </div>
                </div>
              )}
            </div>
            <div className="border-t border-border px-5 py-3 bg-secondary/50 flex gap-3">
              <button onClick={() => { setReplyId(r.id); setReplyText(r.reply || ""); }} className="flex items-center gap-1.5 text-sm text-primary hover:underline" style={{ fontWeight: 600 }}>
                <MessageSquare size={14} /> {t("رد", "Reply")}
              </button>
              <button onClick={() => toggle(r.id)} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
                {r.hidden ? <Eye size={14} /> : <EyeOff size={14} />}
                {r.hidden ? t("إظهار", "Show") : t("إخفاء", "Hide")}
              </button>
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="p-10 text-center text-muted-foreground bg-white rounded-2xl border border-border">
            {t("لا توجد عناصر", "No items found")}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Shared input ─────────────────────────────────────────────────────
function Input({ label, value, onChange, type = "text" }: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <div>
      <label className="block mb-1.5" style={{ fontSize: "14px", fontWeight: 600 }}>{label}</label>
      <input type={type} value={value} onChange={e => onChange(e.target.value)} className="w-full px-4 py-2.5 rounded-xl border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/30" />
    </div>
  );
}
