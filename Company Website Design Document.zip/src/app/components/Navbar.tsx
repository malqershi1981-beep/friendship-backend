import { ShoppingCart, Globe, Menu, X, LogIn, LogOut, Package } from "lucide-react";
import { useState } from "react";
import { useApp } from "../context/AppContext";

export function Navbar() {
  const { lang, setLang, t, cart, currentPage, setCurrentPage, currentUser, logout } = useApp();
  const [menuOpen, setMenuOpen] = useState(false);
  const isRtl = lang === "ar";

  const navItems = [
    { key: "home", ar: "الرئيسية", en: "Home" },
    { key: "stationery", ar: "القرطاسية", en: "Stationery" },
    { key: "computers", ar: "الكمبيوترات", en: "Computers" },
    { key: "banking", ar: "خدمات البنوك", en: "Banking Services" },
    { key: "track", ar: "تتبع الطلب", en: "Track Order" },
  ];

  return (
    <nav className="bg-primary text-primary-foreground shadow-lg sticky top-0 z-50" dir={isRtl ? "rtl" : "ltr"}>
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <button onClick={() => setCurrentPage("home")} className="flex items-center gap-3 hover:opacity-90 transition-opacity">
            <div className="w-10 h-10 rounded-lg bg-accent flex items-center justify-center">
              <Package size={22} className="text-white" />
            </div>
            <div className={isRtl ? "text-right" : "text-left"}>
              <div className="font-bold leading-tight" style={{ fontFamily: "Cairo, sans-serif", fontSize: "15px" }}>
                {t("شركة الصداقة", "Al-Sadaqa Co.")}
              </div>
              <div className="opacity-70 leading-tight" style={{ fontSize: "11px" }}>
                {t("للتجارة والتوكيلات العامة", "Trading & General Agencies")}
              </div>
            </div>
          </button>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-1">
            {navItems.map(item => (
              <button
                key={item.key}
                onClick={() => { setCurrentPage(item.key); setMenuOpen(false); }}
                className={`px-3 py-2 rounded-md transition-colors text-sm ${currentPage === item.key ? "bg-white/20 font-semibold" : "hover:bg-white/10"}`}
                style={{ fontFamily: isRtl ? "Cairo, sans-serif" : "Inter, sans-serif" }}
              >
                {isRtl ? item.ar : item.en}
              </button>
            ))}
          </div>

          {/* Right side */}
          <div className="flex items-center gap-2">
            {/* Lang toggle */}
            <button
              onClick={() => setLang(lang === "ar" ? "en" : "ar")}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/15 hover:bg-white/25 transition-colors text-sm"
            >
              <Globe size={14} />
              {lang === "ar" ? "EN" : "عربي"}
            </button>

            {/* Cart */}
            <button
              onClick={() => setCurrentPage("cart")}
              className="relative p-2 rounded-full hover:bg-white/15 transition-colors"
            >
              <ShoppingCart size={20} />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-accent text-white flex items-center justify-center" style={{ fontSize: "11px", fontWeight: 700 }}>
                  {cart.length}
                </span>
              )}
            </button>

            {/* Staff login/portal */}
            {currentUser ? (
              <div className="flex items-center gap-2">
                <button onClick={() => setCurrentPage("portal")} className="px-3 py-1.5 rounded-md bg-accent text-white text-sm hover:opacity-90 transition-opacity">
                  {t("لوحة التحكم", "Panel")}
                </button>
                <button onClick={logout} className="p-2 rounded-full hover:bg-white/15 transition-colors">
                  <LogOut size={18} />
                </button>
              </div>
            ) : (
              <button onClick={() => setCurrentPage("login")} className="flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-white/15 hover:bg-white/25 transition-colors text-sm">
                <LogIn size={16} />
                {t("دخول الموظفين", "Staff Login")}
              </button>
            )}

            {/* Mobile menu toggle */}
            <button className="md:hidden p-2 rounded-full hover:bg-white/15 transition-colors" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div className="md:hidden mt-3 border-t border-white/20 pt-3 flex flex-col gap-1">
            {navItems.map(item => (
              <button
                key={item.key}
                onClick={() => { setCurrentPage(item.key); setMenuOpen(false); }}
                className={`px-4 py-2.5 rounded-md transition-colors text-sm text-${isRtl ? "right" : "left"} ${currentPage === item.key ? "bg-white/20 font-semibold" : "hover:bg-white/10"}`}
                style={{ fontFamily: isRtl ? "Cairo, sans-serif" : "Inter, sans-serif" }}
              >
                {isRtl ? item.ar : item.en}
              </button>
            ))}
          </div>
        )}
      </div>
    </nav>
  );
}
