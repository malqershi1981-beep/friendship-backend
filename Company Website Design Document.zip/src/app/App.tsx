import "../styles/fonts.css";
import { AppProvider, useApp } from "./context/AppContext";
import { Navbar } from "./components/Navbar";
import { HomePage } from "./components/HomePage";
import { ProductsPage } from "./components/ProductsPage";
import { CartPage } from "./components/CartPage";
import { OrderTrackingPage } from "./components/OrderTrackingPage";
import { LoginPage } from "./components/LoginPage";
import { PortalPage } from "./components/PortalPage";

function AppContent() {
  /* MARKER-MAKE-KIT-INVOKED */
  const { currentPage, lang } = useApp();

  // Portal pages take over full screen (no navbar)
  if (currentPage === "portal") return <PortalPage />;
  if (currentPage === "login") return (
    <div style={{ fontFamily: lang === "ar" ? "Cairo, sans-serif" : "Inter, sans-serif" }}>
      <Navbar />
      <LoginPage />
    </div>
  );

  return (
    <div style={{ fontFamily: lang === "ar" ? "Cairo, sans-serif" : "Inter, sans-serif" }} className="min-h-screen bg-background">
      <Navbar />
      <main>
        {currentPage === "home" && <HomePage />}
        {currentPage === "stationery" && <ProductsPage category="stationery" />}
        {currentPage === "computers" && <ProductsPage category="computers" />}
        {currentPage === "banking" && <ProductsPage category="banking" />}
        {currentPage === "cart" && <CartPage />}
        {currentPage === "track" && <OrderTrackingPage />}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
