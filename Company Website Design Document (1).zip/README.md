
  # Company Website Design Document

  This is a code bundle for Company Website Design Document. The original project is available at https://www.figma.com/design/vgofIsX1GpT2Vagij1tfdd/Company-Website-Design-Document.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  