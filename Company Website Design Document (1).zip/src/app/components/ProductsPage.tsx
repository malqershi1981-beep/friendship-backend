import { useState } from "react";
import { ShoppingCart, Search, SlidersHorizontal } from "lucide-react";
import { useApp } from "../context/AppContext";

interface ProductsPageProps {
  categoryId: string;
}

export function ProductsPage({ categoryId }: ProductsPageProps) {
  const { lang, t, products, categories, addToCart, setCurrentPage, currency } = useApp();
  const isRtl = lang === "ar";
  const [search, setSearch] = useState("");
  const [addedId, setAddedId] = useState<string | null>(null);
  const [qty, setQty] = useState<Record<string, number>>({});

  const category = categories.find(c => c.id === categoryId);
  const filtered = products.filter(p => p.category === categoryId && p.available && (
    search === "" || p.nameAr.includes(search) || p.nameEn.toLowerCase().includes(search.toLowerCase())
  ));

  const heroBg = { stationery: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200&h=280&fit=crop&auto=format", computers: "https://images.unsplash.com/photo-1498049794561-7780e7231661?w=1200&h=280&fit=crop&auto=format", banking: "https://images.unsplash.com/photo-1601597111158-2fceff292cdc?w=1200&h=280&fit=crop&auto=format" };
  const bgUrl = heroBg[categoryId as keyof typeof heroBg] || `https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200&h=280&fit=crop&auto=format`;

  const handleAdd = (p: typeof products[0]) => {
    addToCart(p, qty[p.id] || 1);
    setAddedId(p.id);
    setTimeout(() => setAddedId(null), 1500);
  };

  return (
    <div dir={isRtl ? "rtl" : "ltr"} style={{ fontFamily: isRtl ? "Cairo, sans-serif" : "Inter, sans-serif" }}>
      {/* Hero */}
      <div className="relative overflow-hidden" style={{ height: "220px" }}>
        <img src={bgUrl} alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0 flex items-center justify-center" style={{ background: "linear-gradient(135deg, rgba(10,22,40,0.80), rgba(30,58,110,0.75))" }}>
          <div className="text-center text-white">
            <div style={{ fontSize: "48px", marginBottom: "8px" }}>{category?.icon || "📦"}</div>
            <h1 style={{ fontSize: "clamp(22px, 4vw, 36px)", fontWeight: 900, marginBottom: "6px" }}>
              {category ? (isRtl ? category.nameAr : category.nameEn) : categoryId}
            </h1>
            <p style={{ opacity: 0.75, fontSize: "15px" }}>{filtered.length} {t("منتج متوفر", "products available")}</p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Toolbar */}
        <div className="flex flex-wrap gap-4 mb-8 items-center">
          <div className="relative flex-1 min-w-[240px] max-w-md">
            <Search size={18} className="absolute top-1/2 -translate-y-1/2 text-muted-foreground" style={{ [isRtl ? "right" : "left"]: "14px" }} />
            <input
              placeholder={t("ابحث عن منتج...", "Search products...")}
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full py-3 rounded-2xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-primary/20 shadow-sm"
              style={{ [isRtl ? "paddingRight" : "paddingLeft"]: "44px", paddingLeft: isRtl ? "16px" : "44px", paddingRight: isRtl ? "44px" : "16px" }}
            />
          </div>
          <button
            onClick={() => setCurrentPage("cart")}
            className="flex items-center gap-2 px-6 py-3 rounded-2xl text-white font-bold transition-all hover:opacity-90 shadow-sm"
            style={{ background: "linear-gradient(135deg, #C49A20, #D4A820)" }}
          >
            <ShoppingCart size={18} />
            {t("عرض السلة", "View Cart")}
          </button>
        </div>

        {/* Grid */}
        {filtered.length === 0 ? (
          <div className="text-center py-24 text-muted-foreground">
            <SlidersHorizontal size={56} className="mx-auto mb-4 opacity-30" />
            <p style={{ fontSize: "18px", fontWeight: 600 }}>{t("لا توجد منتجات", "No products found")}</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filtered.map(p => (
              <div key={p.id} className="bg-white rounded-3xl shadow-sm border border-border overflow-hidden hover:shadow-xl transition-all hover:-translate-y-1 flex flex-col group">
                <div className="overflow-hidden" style={{ height: "200px", background: "#f0f4fd" }}>
                  <img src={p.image} alt={isRtl ? p.nameAr : p.nameEn} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="p-5 flex flex-col flex-1">
                  <h3 style={{ fontWeight: 700, color: "var(--foreground)", marginBottom: "6px", fontSize: "15px" }}>
                    {isRtl ? p.nameAr : p.nameEn}
                  </h3>
                  <p className="text-muted-foreground flex-1 mb-4" style={{ fontSize: "13px", lineHeight: 1.6 }}>
                    {isRtl ? p.descAr : p.descEn}
                  </p>

                  <div className="flex items-center gap-2 mb-4">
                    <span className="text-muted-foreground text-sm">{t("الكمية:", "Qty:")}</span>
                    <input
                      type="number" min={1} max={p.stock}
                      value={qty[p.id] || 1}
                      onChange={e => setQty(q => ({ ...q, [p.id]: Math.max(1, parseInt(e.target.value) || 1) }))}
                      className="w-20 px-3 py-1.5 rounded-xl border border-border text-center focus:outline-none focus:ring-2 focus:ring-primary/20 bg-input-background"
                      style={{ fontSize: "14px" }}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div style={{ fontWeight: 900, fontSize: "22px", color: "var(--primary)" }}>
                        {currency}{p.price.toFixed(2)}
                      </div>
                      <div className="text-muted-foreground" style={{ fontSize: "11px" }}>
                        {t("المتوفر:", "Stock:")} {p.stock}
                      </div>
                    </div>
                    <button
                      onClick={() => handleAdd(p)}
                      className={`flex items-center gap-1.5 px-5 py-2.5 rounded-xl font-bold transition-all active:scale-95 ${addedId === p.id ? "bg-green-500 text-white" : "text-white hover:opacity-90"}`}
                      style={addedId === p.id ? {} : { background: "linear-gradient(135deg, #0D1E40, #1E3A6E)" }}
                    >
                      {addedId === p.id ? (
                        <><span>✓</span> {t("أضيف", "Added")}</>
                      ) : (
                        <><ShoppingCart size={16} /> {t("أضف", "Add")}</>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
