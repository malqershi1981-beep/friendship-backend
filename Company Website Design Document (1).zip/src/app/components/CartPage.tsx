import { useState } from "react";
import { Trash2, ShoppingBag, FileText, CreditCard, Building2, Banknote, Mail, CheckCircle } from "lucide-react";
import { useApp } from "../context/AppContext";
import type { Order } from "../context/AppContext";
import jsPDF from "jspdf";

export function CartPage() {
  const { lang, t, cart, removeFromCart, updateCartQty, clearCart, cartTotal, banks, setCurrentPage, setOrders, currency } = useApp();
  const isRtl = lang === "ar";

  const [step, setStep] = useState<"cart" | "checkout" | "success">("cart");
  const [orderType, setOrderType] = useState<"quotation" | "purchase">("purchase");
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "bank_transfer">("cash");
  const [selectedBank, setSelectedBank] = useState("");
  const [transferRef, setTransferRef] = useState("");
  const [validity, setValidity] = useState(7);
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);
  const [emailSent, setEmailSent] = useState(false);

  const activeBanks = banks.filter(b => b.active);

  const mockSendEmail = (orderId: string, email: string) => {
    // Mock email sending — in production replace with real API call
    console.log(`[Mock Email] Sending order ID ${orderId} to ${email}`);
    setEmailSent(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const order: Order = {
      id: `ORD-${Date.now()}`,
      customerName,
      customerPhone,
      customerEmail,
      deliveryAddress,
      items: [...cart],
      total: cartTotal,
      paymentMethod,
      bankId: paymentMethod === "bank_transfer" ? selectedBank : undefined,
      transferRef: paymentMethod === "bank_transfer" ? transferRef : undefined,
      status: orderType === "quotation" ? "closed" : "pending",
      createdAt: new Date(),
      isQuotation: orderType === "quotation",
      quotationValidity: orderType === "quotation" ? validity : undefined,
    };
    setOrders(prev => [...prev, order]);
    setCreatedOrder(order);
    clearCart();
    if (customerEmail) mockSendEmail(order.id, customerEmail);
    setStep("success");
  };

  const downloadQuotationPDF = () => {
    if (!createdOrder) return;
    const doc = new jsPDF();
    doc.setFont("helvetica");
    doc.setFontSize(20);
    doc.text("Al-Sadaqa Trading & General Agencies", 14, 22);
    doc.setFontSize(11);
    doc.setTextColor(100);
    doc.text("info@alsadaqa.sd | +249 912 345 678 | Khartoum, Sudan", 14, 30);
    doc.setTextColor(0);
    doc.setFontSize(15);
    doc.text(orderType === "quotation" ? "PRICE QUOTATION" : "PURCHASE ORDER", 14, 44);
    doc.setFontSize(11);
    doc.text(`ID: ${createdOrder.id}`, 14, 52);
    doc.text(`Date: ${createdOrder.createdAt.toLocaleDateString()}`, 14, 60);
    if (createdOrder.isQuotation) doc.text(`Valid for: ${createdOrder.quotationValidity} days`, 14, 68);
    doc.text(`Customer: ${createdOrder.customerName}`, 14, 76);
    doc.text(`Phone: ${createdOrder.customerPhone}`, 14, 84);
    if (createdOrder.customerEmail) doc.text(`Email: ${createdOrder.customerEmail}`, 14, 92);
    let y = 104;
    doc.line(14, y - 4, 196, y - 4);
    doc.setFontSize(11);
    doc.text("Item", 14, y); doc.text("Qty", 120, y); doc.text("Unit Price", 142, y); doc.text("Total", 174, y);
    doc.line(14, y + 4, 196, y + 4);
    y += 12;
    createdOrder.items.forEach(item => {
      doc.text(item.product.nameEn.substring(0, 38), 14, y);
      doc.text(String(item.quantity), 120, y);
      doc.text(`$${item.product.price.toFixed(2)}`, 142, y);
      doc.text(`$${(item.product.price * item.quantity).toFixed(2)}`, 174, y);
      y += 9;
    });
    doc.line(14, y, 196, y); y += 8;
    doc.setFontSize(13);
    doc.text(`TOTAL: $${createdOrder.total.toFixed(2)}`, 14, y);
    doc.save(`${createdOrder.isQuotation ? "quotation" : "order"}-${createdOrder.id}.pdf`);
  };

  if (step === "success" && createdOrder) {
    return (
      <div dir={isRtl ? "rtl" : "ltr"} style={{ fontFamily: isRtl ? "Cairo, sans-serif" : "Inter, sans-serif" }} className="min-h-screen bg-background flex items-center justify-center p-6">
        <div className="bg-white rounded-3xl shadow-xl border border-border p-10 max-w-lg w-full text-center">
          <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6" style={{ background: "linear-gradient(135deg, #0D1E40, #1E3A6E)" }}>
            <CheckCircle size={40} className="text-white" />
          </div>
          <h2 style={{ fontSize: "26px", fontWeight: 800, color: "var(--primary)", marginBottom: "10px" }}>
            {createdOrder.isQuotation ? t("تم إنشاء عرض السعر", "Quotation Created") : t("تم إرسال طلبك", "Order Submitted")}
          </h2>
          <div className="inline-block px-5 py-2 rounded-full bg-primary/8 border border-primary/20 mb-3">
            <span className="text-muted-foreground text-sm">{t("رقم الطلب:", "Order ID:")}</span>{" "}
            <strong className="text-primary" style={{ fontSize: "16px" }}>{createdOrder.id}</strong>
          </div>
          {createdOrder.isQuotation && (
            <p className="text-muted-foreground mb-2 text-sm">
              {t(`صالح لمدة ${createdOrder.quotationValidity} يوم`, `Valid for ${createdOrder.quotationValidity} days`)}
            </p>
          )}
          {emailSent && createdOrder.customerEmail && (
            <div className="flex items-center justify-center gap-2 py-2 px-4 rounded-xl bg-green-50 border border-green-200 text-green-700 mb-5 text-sm font-semibold">
              <Mail size={16} />
              {t(`تم إرسال رقم الطلب على ${createdOrder.customerEmail}`, `Order ID sent to ${createdOrder.customerEmail}`)}
            </div>
          )}
          <div className="flex flex-col gap-3 mt-6">
            <button onClick={downloadQuotationPDF} className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl text-white font-bold hover:opacity-90 transition-opacity" style={{ background: "linear-gradient(135deg, #0D1E40, #1E3A6E)" }}>
              <FileText size={18} />
              {t("تنزيل PDF", "Download PDF")}
            </button>
            {!createdOrder.isQuotation && (
              <button onClick={() => setCurrentPage("track")} className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl border-2 border-primary text-primary font-bold hover:bg-primary/5 transition-colors">
                {t("تتبع الطلب", "Track Order")}
              </button>
            )}
            <button onClick={() => { setCurrentPage("home"); setStep("cart"); }} className="px-6 py-3 rounded-xl border border-border hover:bg-secondary transition-colors font-semibold">
              {t("العودة للرئيسية", "Back to Home")}
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (cart.length === 0 && step === "cart") {
    return (
      <div dir={isRtl ? "rtl" : "ltr"} style={{ fontFamily: isRtl ? "Cairo, sans-serif" : "Inter, sans-serif" }} className="min-h-screen bg-background flex items-center justify-center p-6">
        <div className="text-center">
          <ShoppingBag size={80} className="mx-auto mb-6 text-muted-foreground opacity-30" />
          <h2 style={{ fontSize: "24px", fontWeight: 800, color: "var(--foreground)", marginBottom: "8px" }}>
            {t("سلتك فارغة", "Your cart is empty")}
          </h2>
          <p className="text-muted-foreground mb-8">{t("أضف بعض المنتجات للبدء", "Add some products to get started")}</p>
          <button onClick={() => setCurrentPage("home")} className="px-8 py-3.5 rounded-2xl text-white font-bold hover:opacity-90" style={{ background: "linear-gradient(135deg, #0D1E40, #1E3A6E)" }}>
            {t("تصفح المنتجات", "Browse Products")}
          </button>
        </div>
      </div>
    );
  }

  const BtnGrad = ({ children, onClick, type = "button", disabled = false, className = "" }: any) => (
    <button type={type} onClick={onClick} disabled={disabled} className={`px-6 py-3 rounded-xl text-white font-bold transition-all hover:opacity-90 active:scale-95 disabled:opacity-40 ${className}`} style={{ background: "linear-gradient(135deg, #0D1E40, #1E3A6E)" }}>
      {children}
    </button>
  );

  return (
    <div dir={isRtl ? "rtl" : "ltr"} style={{ fontFamily: isRtl ? "Cairo, sans-serif" : "Inter, sans-serif" }} className="bg-background min-h-screen">
      <div className="max-w-5xl mx-auto px-6 py-10">
        {/* Header */}
        <div className="mb-8">
          <h1 style={{ fontSize: "32px", fontWeight: 900, color: "var(--primary)" }}>
            {step === "cart" ? t("سلة المشتريات", "Shopping Cart") : t("إتمام الطلب", "Checkout")}
          </h1>
        </div>

        {step === "cart" && (
          <>
            {/* Order type toggle */}
            <div className="flex gap-3 mb-6">
              {[
                { v: "purchase", icon: <CreditCard size={18} />, ar: "طلب شراء", en: "Purchase Order" },
                { v: "quotation", icon: <FileText size={18} />, ar: "طلب عرض سعر", en: "Request Quotation" },
              ].map(opt => (
                <button
                  key={opt.v}
                  onClick={() => setOrderType(opt.v as any)}
                  className={`flex items-center gap-2 px-6 py-3 rounded-2xl border-2 font-bold transition-all ${orderType === opt.v ? "border-primary text-white" : "border-border bg-white hover:border-primary/40"}`}
                  style={orderType === opt.v ? { background: "linear-gradient(135deg, #0D1E40, #1E3A6E)" } : {}}
                >
                  {opt.icon} {isRtl ? opt.ar : opt.en}
                </button>
              ))}
            </div>

            {/* Cart items */}
            <div className="bg-white rounded-3xl shadow-sm border border-border overflow-hidden mb-6">
              {cart.map((item, idx) => (
                <div key={item.product.id} className={`flex items-center gap-4 p-4 ${idx < cart.length - 1 ? "border-b border-border" : ""}`}>
                  <img src={item.product.image} alt="" className="w-16 h-16 rounded-2xl object-cover flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div style={{ fontWeight: 700 }}>{isRtl ? item.product.nameAr : item.product.nameEn}</div>
                    <div style={{ fontWeight: 700, color: "var(--accent)" }}>{currency}{item.product.price.toFixed(2)}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => updateCartQty(item.product.id, item.quantity - 1)} className="w-8 h-8 rounded-lg border border-border flex items-center justify-center hover:bg-secondary font-bold">−</button>
                    <span className="w-10 text-center font-bold">{item.quantity}</span>
                    <button onClick={() => updateCartQty(item.product.id, item.quantity + 1)} className="w-8 h-8 rounded-lg border border-border flex items-center justify-center hover:bg-secondary font-bold">+</button>
                  </div>
                  <div style={{ fontWeight: 800, color: "var(--primary)", minWidth: "80px", textAlign: isRtl ? "left" : "right" }}>
                    {currency}{(item.product.price * item.quantity).toFixed(2)}
                  </div>
                  <button onClick={() => removeFromCart(item.product.id)} className="p-2 rounded-xl hover:bg-red-50 text-destructive transition-colors">
                    <Trash2 size={18} />
                  </button>
                </div>
              ))}
            </div>

            {/* Total & proceed */}
            <div className="flex items-center justify-between bg-white rounded-3xl shadow-sm border border-border p-6">
              <div>
                <div className="text-muted-foreground text-sm">{t("الإجمالي", "Total")}</div>
                <div style={{ fontSize: "32px", fontWeight: 900, color: "var(--primary)" }}>{currency}{cartTotal.toFixed(2)}</div>
              </div>
              <BtnGrad type="button" onClick={() => setStep("checkout")} className="px-10 py-4 text-lg">
                {orderType === "quotation" ? t("إنشاء عرض السعر", "Create Quotation") : t("متابعة الدفع", "Proceed to Checkout")}
              </BtnGrad>
            </div>
          </>
        )}

        {step === "checkout" && (
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Customer info */}
            <div className="bg-white rounded-3xl shadow-sm border border-border p-6">
              <h3 style={{ fontSize: "18px", fontWeight: 800, color: "var(--primary)", marginBottom: "18px" }}>
                {t("بيانات العميل", "Customer Details")}
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <Field label={t("الاسم أو اسم الشركة *", "Name / Company *")}>
                  <input required value={customerName} onChange={e => setCustomerName(e.target.value)} className="field-input" />
                </Field>
                <Field label={t("رقم الهاتف *", "Phone *")}>
                  <input required value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} className="field-input" />
                </Field>
                <div className="md:col-span-2">
                  <Field label={t("البريد الإلكتروني", "Email Address")}>
                    <div className="relative">
                      <Mail size={16} className="absolute top-1/2 -translate-y-1/2 text-muted-foreground" style={{ [isRtl ? "right" : "left"]: "14px" }} />
                      <input
                        type="email"
                        value={customerEmail}
                        onChange={e => setCustomerEmail(e.target.value)}
                        placeholder={t("سيُرسل رقم الطلب على بريدك (اختياري)", "Order ID will be sent here (optional)")}
                        className="w-full py-3 rounded-xl border border-border bg-input-background focus:outline-none focus:ring-2 focus:ring-primary/20"
                        style={{ [isRtl ? "paddingRight" : "paddingLeft"]: "40px", paddingLeft: isRtl ? "14px" : "40px", paddingRight: isRtl ? "40px" : "14px" }}
                      />
                    </div>
                  </Field>
                </div>
                {orderType !== "quotation" && (
                  <div className="md:col-span-2">
                    <Field label={t("عنوان التوصيل *", "Delivery Address *")}>
                      <input required value={deliveryAddress} onChange={e => setDeliveryAddress(e.target.value)} className="field-input" />
                    </Field>
                  </div>
                )}
                {orderType === "quotation" && (
                  <Field label={t("فترة الصلاحية (أيام)", "Validity (days)")}>
                    <input type="number" min={1} value={validity} onChange={e => setValidity(parseInt(e.target.value) || 7)} className="field-input" />
                  </Field>
                )}
              </div>
            </div>

            {/* Payment */}
            {orderType !== "quotation" && (
              <div className="bg-white rounded-3xl shadow-sm border border-border p-6">
                <h3 style={{ fontSize: "18px", fontWeight: 800, color: "var(--primary)", marginBottom: "18px" }}>
                  {t("طريقة الدفع", "Payment Method")}
                </h3>
                <div className="flex flex-wrap gap-3 mb-6">
                  {[
                    { v: "cash", icon: <Banknote size={20} />, ar: "نقداً عند التسليم", en: "Cash on Delivery" },
                    { v: "bank_transfer", icon: <Building2 size={20} />, ar: "تحويل بنكي", en: "Bank Transfer" },
                  ].map(opt => (
                    <button key={opt.v} type="button" onClick={() => setPaymentMethod(opt.v as any)}
                      className={`flex items-center gap-2 px-6 py-3 rounded-2xl border-2 font-bold transition-all ${paymentMethod === opt.v ? "border-primary text-white" : "border-border bg-white hover:border-primary/40"}`}
                      style={paymentMethod === opt.v ? { background: "linear-gradient(135deg, #0D1E40, #1E3A6E)" } : {}}>
                      {opt.icon} {isRtl ? opt.ar : opt.en}
                    </button>
                  ))}
                </div>

                {paymentMethod === "bank_transfer" && (
                  <div className="space-y-4">
                    <Field label={t("اختر البنك *", "Select Bank *")}>
                      <select required value={selectedBank} onChange={e => setSelectedBank(e.target.value)} className="field-input">
                        <option value="">{t("-- اختر البنك --", "-- Select Bank --")}</option>
                        {activeBanks.map(b => <option key={b.id} value={b.id}>{isRtl ? b.nameAr : b.nameEn} — {b.accountNumber}</option>)}
                      </select>
                    </Field>
                    {selectedBank && (
                      <div className="p-5 rounded-2xl border-2 border-primary/20" style={{ background: "linear-gradient(135deg, #f5f8ff, #edf1fb)" }}>
                        <div className="text-sm text-muted-foreground mb-1">{t("رقم الحساب البنكي", "Bank Account Number")}</div>
                        <div style={{ fontFamily: "monospace", fontSize: "22px", fontWeight: 800, color: "var(--primary)", letterSpacing: "3px" }}>
                          {activeBanks.find(b => b.id === selectedBank)?.accountNumber}
                        </div>
                      </div>
                    )}
                    <Field label={t("الرقم المرجعي للتحويل *", "Transfer Reference *")}>
                      <input required value={transferRef} onChange={e => setTransferRef(e.target.value)} className="field-input" placeholder={t("أدخل رقم العملية", "Enter transaction reference")} />
                    </Field>
                  </div>
                )}
              </div>
            )}

            {/* Summary */}
            <div className="bg-white rounded-3xl shadow-sm border border-border p-6">
              <h3 style={{ fontSize: "18px", fontWeight: 800, color: "var(--primary)", marginBottom: "16px" }}>{t("ملخص الطلب", "Order Summary")}</h3>
              {cart.map(item => (
                <div key={item.product.id} className="flex justify-between py-2.5 border-b border-border last:border-0">
                  <span>{isRtl ? item.product.nameAr : item.product.nameEn} <span className="text-muted-foreground">× {item.quantity}</span></span>
                  <span style={{ fontWeight: 700 }}>{currency}{(item.product.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
              <div className="flex justify-between pt-4 mt-1">
                <span style={{ fontWeight: 800, fontSize: "18px" }}>{t("الإجمالي", "Total")}</span>
                <span style={{ fontWeight: 900, fontSize: "24px", color: "var(--primary)" }}>{currency}{cartTotal.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex gap-3">
              <button type="button" onClick={() => setStep("cart")} className="flex-1 py-4 rounded-2xl border-2 border-border bg-white hover:bg-secondary font-bold transition-colors">
                {t("رجوع", "Back")}
              </button>
              <button type="submit" className="flex-1 py-4 rounded-2xl text-white font-bold text-lg transition-all hover:opacity-90" style={{ background: "linear-gradient(135deg, #0D1E40, #1E3A6E)" }}>
                {orderType === "quotation" ? t("إنشاء عرض السعر", "Create Quotation") : t("تأكيد الطلب", "Confirm Order")}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block mb-1.5" style={{ fontSize: "14px", fontWeight: 600 }}>{label}</label>
      {children}
    </div>
  );
}

// Inject shared input class via a style tag workaround — just reuse inline
declare global { interface HTMLElementTagNameMap { } }
