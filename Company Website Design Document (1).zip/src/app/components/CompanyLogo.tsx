interface CompanyLogoProps {
  size?: "sm" | "md" | "lg";
  variant?: "light" | "dark";
}

export function CompanyLogo({ size = "md", variant = "light" }: CompanyLogoProps) {
  const dims = { sm: 36, md: 48, lg: 80 };
  const d = dims[size];
  const textColor = variant === "light" ? "#FFFFFF" : "#0D1E40";
  const accentColor = "#C49A20";

  return (
    <svg width={d} height={d} viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Outer circle with gradient */}
      <defs>
        <linearGradient id="logoGrad" x1="0" y1="0" x2="80" y2="80" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#1E3A6E" />
          <stop offset="100%" stopColor="#0D1E40" />
        </linearGradient>
        <linearGradient id="accentGrad" x1="0" y1="0" x2="80" y2="0" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#D4A820" />
          <stop offset="100%" stopColor="#C49A20" />
        </linearGradient>
      </defs>

      {/* Background circle */}
      <circle cx="40" cy="40" r="40" fill="url(#logoGrad)" />

      {/* Gold arc top */}
      <path d="M15 40 Q40 10 65 40" stroke="url(#accentGrad)" strokeWidth="3" fill="none" strokeLinecap="round" />

      {/* Arabic ص stylized */}
      <text
        x="40"
        y="50"
        textAnchor="middle"
        fill="#FFFFFF"
        style={{ fontFamily: "Cairo, sans-serif", fontSize: "28px", fontWeight: 800 }}
      >
        ص
      </text>

      {/* Gold dot accent */}
      <circle cx="40" cy="63" r="3" fill={accentColor} />

      {/* Side dots */}
      <circle cx="20" cy="40" r="2.5" fill={accentColor} opacity="0.7" />
      <circle cx="60" cy="40" r="2.5" fill={accentColor} opacity="0.7" />
    </svg>
  );
}
