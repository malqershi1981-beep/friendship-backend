import { useState } from "react";
import { Search, FileText, ShoppingCart, CheckCircle, Building2, Banknote, Mail } from "lucide-react";
import { useApp } from "../context/AppContext";
import type { Order } from "../context/AppContext";
import jsPDF from "jspdf";

export function QuotationPurchasePage() {
  const { lang, t, orders, setOrders, banks, currency } = useApp();
  const isRtl = lang === "ar";

  const [searchId, setSearchId] = useState("");
  const [searched, setSearched] = useState(false);
  const [step, setStep] = useState<"search" | "checkout" | "success">("search");
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);

  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"cash" | "bank_transfer">("cash");
  const [selectedBank, setSelectedBank] = useState("");
  const [transferRef, setTransferRef] = useState("");
  const [emailSent, setEmailSent] = useState(false);

  const activeBanks = banks.filter(b => b.active);
  const foundQuotation = orders.find(o => o.id === searchId.trim() && o.isQuotation);

  const startCheckout = () => {
    if (!foundQuotation) return;
    setCustomerName(foundQuotation.customerName);
    setCustomerPhone(foundQuotation.customerPhone);
    setCustomerEmail(foundQuotation.customerEmail || "");
    setDeliveryAddress(foundQuotation.deliveryAddress || "");
    setStep("checkout");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!foundQuotation) return;
    const order: Order = {
      id: `ORD-${Date.now()}`,
      customerName,
      customerPhone,
      customerEmail,
      deliveryAddress,
      items: foundQuotation.items,
      total: foundQuotation.total,
      paymentMethod,
      bankId: paymentMethod === "bank_transfer" ? selectedBank : undefined,
      transferRef: paymentMethod === "bank_transfer" ? transferRef : undefined,
      status: "pending",
      createdAt: new Date(),
      isQuotation: false,
    };
    setOrders(prev => [...prev, order]);
    setCreatedOrder(order);
    if (customerEmail) setEmailSent(true);
    setStep("success");
  };

  const downloadPDF = () => {
    if (!createdOrder) return;
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text("Al-Sadaqa Trading & General Agencies", 14, 20);
    doc.setFontSize(12);
    doc.text(`PURCHASE ORDER: ${createdOrder.id}`, 14, 32);
    doc.text(`Date: ${createdOrder.createdAt.toLocaleDateString()}`, 14, 42);
    doc.text(`Customer: ${createdOrder.customerName} | Phone: ${createdOrder.customerPhone}`, 14, 52);
    if (createdOrder.customerEmail) doc.text(`Email: ${createdOrder.customerEmail}`, 14, 62);
    doc.text(`Address: ${createdOrder.deliveryAddress}`, 14, 72);
    let y = 86;
    doc.line(14, y - 4, 196, y - 4);
    doc.text("Item", 14, y); doc.text("Qty", 120, y); doc.text("Price", 148, y); doc.text("Total", 176, y);
    doc.line(14, y + 4, 196, y + 4);
    y += 12;
    createdOrder.items.forEach(item => {
      doc.text(item.product.nameEn.substring(0, 38), 14, y);
      doc.text(String(item.quantity), 120, y);
      doc.text(`$${item.product.price.toFixed(2)}`, 148, y);
      doc.text(`$${(item.product.price * item.quantity).toFixed(2)}`, 176, y);
      y += 9;
    });
    doc.line(14, y, 196, y); y += 8;
    doc.setFontSize(14);
    doc.text(`TOTAL: $${createdOrder.total.toFixed(2)}`, 14, y);
    doc.save(`purchase-order-${createdOrder.id}.pdf`);
  };

  if (step === "success" && createdOrder) {
    return (
      <div dir={isRtl ? "rtl" : "ltr"} style={{ fontFamily: isRtl ? "Cairo, sans-serif" : "Inter, sans-serif" }} className="min-h-screen bg-background flex items-center justify-center p-6">
        <div className="bg-white rounded-3xl shadow-xl border border-border p-10 max-w-lg w-full text-center">
          <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6" style={{ background: "linear-gradient(135deg, #0D1E40, #1E3A6E)" }}>
            <CheckCircle size={40} className="text-white" />
          </div>
          <h2 style={{ fontSize: "26px", fontWeight: 800, color: "var(--primary)", marginBottom: "10px" }}>
            {t("تم إنشاء طلب الشراء", "Purchase Order Created")}
          </h2>
          <div className="inline-block px-5 py-2 rounded-full border border-primary/20 mb-4" style={{ background: "rgba(13,30,64,0.06)" }}>
            <span className="text-muted-foreground text-sm">{t("رقم الطلب:", "Order ID:")}</span>{" "}
            <strong className="text-primary text-lg">{createdOrder.id}</strong>
          </div>
          {emailSent && createdOrder.customerEmail && (
            <div className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-green-50 border border-green-200 text-green-700 mb-5 text-sm font-semibold">
              <Mail size={16} />
              {t(`تم إرسال رقم الطلب إلى ${createdOrder.customerEmail}`, `Order ID sent to ${createdOrder.customerEmail}`)}
            </div>
          )}
          <div className="bg-secondary rounded-2xl p-4 mb-6 text-sm text-muted-foreground">
            {t("تم تحويل عرض السعر إلى طلب شراء وسيتم متابعته مع فريق خدمة العملاء", "Quotation successfully converted to a purchase order and will be processed by our team.")}
          </div>
          <div className="flex flex-col gap-3">
            <button onClick={downloadPDF} className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl text-white font-bold hover:opacity-90" style={{ background: "linear-gradient(135deg, #0D1E40, #1E3A6E)" }}>
              <FileText size={18} /> {t("تنزيل طلب الشراء PDF", "Download Purchase Order PDF")}
            </button>
            <button onClick={() => { setStep("search"); setSearchId(""); setSearched(false); }} className="px-6 py-3 rounded-xl border border-border hover:bg-secondary font-semibold">
              {t("تحويل عرض سعر آخر", "Convert Another Quotation")}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div dir={isRtl ? "rtl" : "ltr"} style={{ fontFamily: isRtl ? "Cairo, sans-serif" : "Inter, sans-serif" }} className="bg-background min-h-screen">
      {/* Hero */}
      <div style={{ background: "linear-gradient(135deg, #0A1628 0%, #0D1E40 60%, #1E3A6E 100%)", padding: "60px 24px" }} className="text-white text-center">
        <div style={{ fontSize: "52px", marginBottom: "16px" }}>📋</div>
        <h1 style={{ fontSize: "clamp(22px, 4vw, 34px)", fontWeight: 900, marginBottom: "10px" }}>
          {t("طلب شراء من عرض سعر", "Purchase Order from Quotation")}
        </h1>
        <p style={{ opacity: 0.75, fontSize: "16px", maxWidth: "500px", margin: "0 auto" }}>
          {t("أدخل رقم عرض السعر لتحويله إلى طلب شراء واستكمال إجراءات الدفع والتوصيل", "Enter your quotation number to convert it to a purchase order and complete payment and delivery")}
        </p>
      </div>

      <div className="max-w-2xl mx-auto px-6 py-12">
        {step === "search" && (
          <>
            {/* Search box */}
            <div className="bg-white rounded-3xl shadow-sm border border-border p-8 mb-6">
              <h3 style={{ fontWeight: 800, fontSize: "18px", color: "var(--primary)", marginBottom: "20px" }}>
                {t("أدخل رقم عرض السعر", "Enter Quotation Number")}
              </h3>
              <div className="flex gap-3">
                <input
                  value={searchId}
                  onChange={e => setSearchId(e.target.value)}
                  placeholder="ORD-..."
                  className="flex-1 field-input"
                  onKeyDown={e => { if (e.key === "Enter") setSearched(true); }}
                />
                <button
                  onClick={() => setSearched(true)}
                  className="flex items-center gap-2 px-6 py-3 rounded-xl text-white font-bold transition-all hover:opacity-90"
                  style={{ background: "linear-gradient(135deg, #0D1E40, #1E3A6E)" }}
                >
                  <Search size={18} /> {t("بحث", "Search")}
                </button>
              </div>
            </div>

            {searched && !foundQuotation && (
              <div className="bg-white rounded-3xl border border-border p-10 text-center">
                <FileText size={60} className="mx-auto mb-4 text-muted-foreground opacity-30" />
                <h3 style={{ fontSize: "18px", fontWeight: 700, color: "var(--foreground)", marginBottom: "8px" }}>
                  {t("لم يتم العثور على عرض السعر", "Quotation Not Found")}
                </h3>
                <p className="text-muted-foreground text-sm">
                  {t("تأكد من رقم عرض السعر وحاول مرة أخرى", "Please verify the quotation number and try again")}
                </p>
              </div>
            )}

            {searched && foundQuotation && (
              <div className="bg-white rounded-3xl shadow-sm border border-border overflow-hidden">
                <div style={{ background: "linear-gradient(135deg, #0D1E40, #1E3A6E)" }} className="px-6 py-4 text-white flex items-center justify-between">
                  <div>
                    <div style={{ fontWeight: 800, fontSize: "18px" }}>{foundQuotation.id}</div>
                    <div style={{ opacity: 0.75, fontSize: "14px" }}>{new Date(foundQuotation.createdAt).toLocaleDateString(isRtl ? "ar" : "en")}</div>
                  </div>
                  <span className="px-3 py-1 rounded-full text-xs font-bold" style={{ background: "rgba(196,154,32,0.3)", color: "#F0C040" }}>
                    {t("عرض سعر", "Quotation")}
                  </span>
                </div>
                <div className="p-6">
                  <div className="grid grid-cols-2 gap-4 mb-5 text-sm">
                    <div>
                      <div className="text-muted-foreground">{t("العميل", "Customer")}</div>
                      <div style={{ fontWeight: 700 }}>{foundQuotation.customerName}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">{t("الهاتف", "Phone")}</div>
                      <div style={{ fontWeight: 700 }}>{foundQuotation.customerPhone}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">{t("صالح لمدة", "Valid for")}</div>
                      <div style={{ fontWeight: 700 }}>{foundQuotation.quotationValidity} {t("يوم", "days")}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">{t("الإجمالي", "Total")}</div>
                      <div style={{ fontWeight: 800, fontSize: "18px", color: "var(--primary)" }}>{currency}{foundQuotation.total.toFixed(2)}</div>
                    </div>
                  </div>

                  <div className="mb-5">
                    <div style={{ fontWeight: 700, color: "var(--primary)", marginBottom: "10px" }}>{t("الأصناف", "Items")}</div>
                    {foundQuotation.items.map(item => (
                      <div key={item.product.id} className="flex items-center gap-3 py-2.5 border-b border-border last:border-0">
                        <img src={item.product.image} alt="" className="w-10 h-10 rounded-xl object-cover" />
                        <div className="flex-1 text-sm">
                          <div style={{ fontWeight: 600 }}>{isRtl ? item.product.nameAr : item.product.nameEn}</div>
                          <div className="text-muted-foreground">× {item.quantity}</div>
                        </div>
                        <div style={{ fontWeight: 700, color: "var(--accent)" }}>{currency}{(item.product.price * item.quantity).toFixed(2)}</div>
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={startCheckout}
                    className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl text-white font-bold text-lg transition-all hover:opacity-90"
                    style={{ background: "linear-gradient(135deg, #C49A20, #D4A820)" }}
                  >
                    <ShoppingCart size={20} />
                    {t("تحويل إلى طلب شراء", "Convert to Purchase Order")}
                  </button>
                </div>
              </div>
            )}
          </>
        )}

        {step === "checkout" && foundQuotation && (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="bg-white rounded-3xl shadow-sm border border-border p-6">
              <h3 style={{ fontWeight: 800, fontSize: "18px", color: "var(--primary)", marginBottom: "18px" }}>
                {t("بيانات العميل", "Customer Details")}
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block mb-1.5 text-sm font-semibold">{t("الاسم *", "Name *")}</label>
                  <input required value={customerName} onChange={e => setCustomerName(e.target.value)} className="field-input" />
                </div>
                <div>
                  <label className="block mb-1.5 text-sm font-semibold">{t("الهاتف *", "Phone *")}</label>
                  <input required value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} className="field-input" />
                </div>
                <div className="md:col-span-2">
                  <label className="block mb-1.5 text-sm font-semibold">{t("البريد الإلكتروني", "Email")}</label>
                  <div className="relative">
                    <Mail size={16} className="absolute top-1/2 -translate-y-1/2 text-muted-foreground" style={{ [isRtl ? "right" : "left"]: "14px" }} />
                    <input type="email" value={customerEmail} onChange={e => setCustomerEmail(e.target.value)} className="field-input" placeholder={t("اختياري - سيُرسل رقم الطلب", "Optional - order ID will be sent here")} style={{ [isRtl ? "paddingRight" : "paddingLeft"]: "40px" }} />
                  </div>
                </div>
                <div className="md:col-span-2">
                  <label className="block mb-1.5 text-sm font-semibold">{t("عنوان التوصيل *", "Delivery Address *")}</label>
                  <input required value={deliveryAddress} onChange={e => setDeliveryAddress(e.target.value)} className="field-input" />
                </div>
              </div>
            </div>

            {/* Payment */}
            <div className="bg-white rounded-3xl shadow-sm border border-border p-6">
              <h3 style={{ fontWeight: 800, fontSize: "18px", color: "var(--primary)", marginBottom: "18px" }}>
                {t("طريقة الدفع", "Payment Method")}
              </h3>
              <div className="flex flex-wrap gap-3 mb-5">
                {[
                  { v: "cash", icon: <Banknote size={20} />, ar: "نقداً عند التسليم", en: "Cash on Delivery" },
                  { v: "bank_transfer", icon: <Building2 size={20} />, ar: "تحويل بنكي", en: "Bank Transfer" },
                ].map(opt => (
                  <button key={opt.v} type="button" onClick={() => setPaymentMethod(opt.v as any)}
                    className={`flex items-center gap-2 px-6 py-3 rounded-2xl border-2 font-bold transition-all ${paymentMethod === opt.v ? "border-primary text-white" : "border-border bg-white hover:border-primary/40"}`}
                    style={paymentMethod === opt.v ? { background: "linear-gradient(135deg, #0D1E40, #1E3A6E)" } : {}}>
                    {opt.icon} {isRtl ? opt.ar : opt.en}
                  </button>
                ))}
              </div>
              {paymentMethod === "bank_transfer" && (
                <div className="space-y-4">
                  <div>
                    <label className="block mb-1.5 text-sm font-semibold">{t("اختر البنك *", "Select Bank *")}</label>
                    <select required value={selectedBank} onChange={e => setSelectedBank(e.target.value)} className="field-input">
                      <option value="">{t("-- اختر البنك --", "-- Select Bank --")}</option>
                      {activeBanks.map(b => <option key={b.id} value={b.id}>{isRtl ? b.nameAr : b.nameEn} — {b.accountNumber}</option>)}
                    </select>
                  </div>
                  {selectedBank && (
                    <div className="p-5 rounded-2xl border-2 border-primary/20" style={{ background: "linear-gradient(135deg, #f5f8ff, #edf1fb)" }}>
                      <div className="text-sm text-muted-foreground mb-1">{t("رقم الحساب", "Account Number")}</div>
                      <div style={{ fontFamily: "monospace", fontSize: "22px", fontWeight: 800, color: "var(--primary)", letterSpacing: "3px" }}>
                        {activeBanks.find(b => b.id === selectedBank)?.accountNumber}
                      </div>
                    </div>
                  )}
                  <div>
                    <label className="block mb-1.5 text-sm font-semibold">{t("الرقم المرجعي *", "Reference Number *")}</label>
                    <input required value={transferRef} onChange={e => setTransferRef(e.target.value)} className="field-input" placeholder={t("أدخل رقم العملية", "Enter transaction reference")} />
                  </div>
                </div>
              )}
            </div>

            {/* Order summary */}
            <div className="bg-white rounded-3xl shadow-sm border border-border p-6">
              <h3 style={{ fontWeight: 800, fontSize: "18px", color: "var(--primary)", marginBottom: "14px" }}>{t("ملخص الطلب", "Order Summary")}</h3>
              {foundQuotation.items.map(item => (
                <div key={item.product.id} className="flex justify-between py-2 border-b border-border last:border-0">
                  <span className="text-sm">{isRtl ? item.product.nameAr : item.product.nameEn} <span className="text-muted-foreground">× {item.quantity}</span></span>
                  <span style={{ fontWeight: 700 }}>{currency}{(item.product.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
              <div className="flex justify-between pt-4 mt-1">
                <span style={{ fontWeight: 800 }}>{t("الإجمالي", "Total")}</span>
                <span style={{ fontWeight: 900, fontSize: "22px", color: "var(--primary)" }}>{currency}{foundQuotation.total.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex gap-3">
              <button type="button" onClick={() => setStep("search")} className="flex-1 py-4 rounded-2xl border-2 border-border bg-white hover:bg-secondary font-bold">
                {t("رجوع", "Back")}
              </button>
              <button type="submit" className="flex-1 py-4 rounded-2xl text-white font-bold text-lg hover:opacity-90" style={{ background: "linear-gradient(135deg, #0D1E40, #1E3A6E)" }}>
                {t("تأكيد طلب الشراء", "Confirm Purchase Order")}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
